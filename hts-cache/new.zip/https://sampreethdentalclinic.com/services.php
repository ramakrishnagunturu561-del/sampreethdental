<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Specialized dental care to straighten crooked teeth in children and adults. Treat diseases of the gums and the placement of dental implants.">
<meta name="keywords" content="Sampreeth Dental Clinic, Vijayawada Dental Clinic, Top 10 Dental Doctors in Vijayawada, Most Rated Dental Doctor in vijayawada">
<meta name="author" content="Sampreeth Dental Clinc">

<!-- SITE TITLE -->
<title>Sampreeth Dental Clinc | Vijayawada, Andhra Pradesh</title>

<!-- =========================
      FAV AND TOUCH ICONS  
============================== -->
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="apple-touch-icon" href="images/apple-touch-icon.html">
<link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.html">
<link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.html">

<!-- =========================
     STYLESHEETS   
============================== -->

<link rel="stylesheet" type="text/css" href="css/master.css" />
</head>

<body data-spy="scroll" data-target=".navbar">
	<div class="preloader" id="preloader"> 
		<img src="images/preloader.gif" alt="" /> 
	</div>

<!-- =========================
     TOP BAR
============================== -->
<div class="top-bar" id="top-bar">
  <div class="container">
    <div class="row"> 
      
      <!-- TOP BAR LEFT -->
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
        <div class="top-bar-adress"> <i class="flaticon-navigation-arrow"></i> #57-6-2, Venkata Sai Enclave, Opp:Sri Chaitanya English Medium High School, Patamata, Vijayawada. </div>
      </div>
      
      <!-- TOP BAR RIGHT -->
      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
        <div class="top-bar-social"> 
            <a href="#"><i class="fa fa-facebook"></i></a> 
            <a href="#"><i class="fa fa-google-plus"></i></a> 
            <a href="#"><i class="fa fa-twitter"></i></a> 
            <a href="#"><i class="fa fa-skype"></i></a> </div>
        <div class="top-bar-mail"> <i class="fa fa-envelope"></i> <a href="mailto:drnadellaneelima@gmail.com">drnadellaneelima@gmail.com</a> </div>
      </div>
    </div>
  </div>
</div>
<!-- =========================
     END TOP BAR   
============================== --> 

<!-- =========================
     HEADER
============================== -->
<div class="header" id="header">
  <div class="container">
    <div class="row"> 
      
      <!-- HEADER LOGO -->
      <div class="col-lg-6 col-md-6 col-sm-5 col-xs-12">
        <div class="header-logo"> 
            <a href="index.php">
                <img src="img/lg.jpg" alt=""/>
                <span class="bold600 color-child-6">SAMPREETH</span>
                <span class="color-child-5">DENTAL CLINIC</span>
            </a> 
        </div>
      </div>
      
      <!-- HEADER BUTTONS -->
      <div class="col-lg-6 col-md-6 col-sm-7 col-xs-12">
        <div class="header-button"> <a href="#bookform1" class="fancybox-2 btn btn-default">
            <span class="plus">+</span>MAKE AN APPOINTMENT</a> 
		</div>
        <div class="header-phone"> 
			<i class="fa fa-phone"></i> <a href="tel:+917995605888">+91 79956 05888</a>
		</div>
      </div>
    </div>
  </div>
</div>
<!-- =========================
     END HEADER
============================== --> 

<!-- =========================
     MAIN MENU
============================== -->
<div class="top-menu" id="top-menu">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="mobile-bar-cont">
          <div class="top-menu-logo"> <a href="index.php"><img src="img/lg.jpg" alt="" />
              <span class="bold600 color-child-6">
                SAMPREETH
              </span>
              <span class="color-child-5">
                DENTAL CLINIC
              </span>
            </a> </div>
          <div class="mobile-bar">
            <div class="show-menu" id="show-menu"> <i class="fa fa-bars"></i> </div>
            <div class="color-sw-open-1" id="color-sw-open-1"> <i class="fa fa-gear"></i> </div>
          </div>
        </div>
        <ul class="nav navbar-nav">
          <li class="active"><a href="index.php">HOME</a></li>
          <li><a href="about.php">ABOUT US</a></li>
          <li class="dropdown"> <a data-toggle="dropdown" href="">TREATMENTS</a>
            <ul class="dropdown-menu " role="menu">              
				<li><a href="services.php">Teeth whitening</a></li> 
				<li><a href="services.php">Simple Extraction of teeth</a></li> 
				<li><a href="services.php">Surgical removal of Impacted teeth</a></li> 
				<li><a href="services.php">Removal of Cysts& Tumours</a></li> 
				<li><a href="services.php">Fracture Jaw bones</a></li> 
				<li><a href="services.php">Cosmetic Procedures</a></li> 
				<li><a href="services.php">Implants</a></li> 
				<li><a href="services.php">Removable Dentures& Fixed teeth</a></li> 
				<li><a href="services.php">Root canal Treatments</a></li> 
				<li><a href="services.php">Cleaning & Flap Surgeries</a></li> 
				<li><a href="services.php">Correction of Irregular placed Teeth using Braces</a></li> 
				<li><a href="services.php">Treatment for Child Teeth</a></li> 
            </ul>
          </li>
          <!-- <li class="dropdown"> <a data-toggle="dropdown" href="#">OUR DOCTORS</a> -->
            <!-- <ul class="dropdown-menu" role="menu"> -->
              <!-- <li><a href="doctors.html">Our doctors</a></li> -->
              
            <!-- </ul> -->
          <!-- </li> -->
         
		  <li><a href="gallery.php">GALLERY</a></li>
          <!-- <li class="dropdown"> <a data-toggle="dropdown" href="#">PAGES</a> -->
            <!-- <ul class="dropdown-menu" role="menu"> -->
              <!-- <li><a href="gallery1.html">Gallery 1</a></li> -->
              <!-- <li><a href="gallery2.html">Gallery 2</a></li> -->
              <!-- <li><a href="prices.html">Prices</a></li> -->
              <!-- <li><a href="timetable.html">Timetable</a></li> -->
              <!-- <li><a href="payment.html">Payments</a></li> -->
              <!-- <li><a href="404.html">404 Page</a></li> -->
            <!-- </ul> -->
          <!-- </li> -->
          <li><a href="contact.php">CONTACT US</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
<!-- =========================
     END MAIN MENU
============================== --> 

<!-- =========================
     HEADER SLIDER
============================== -->
<div id="slider" class="slider">
	<div class="sp-slides"> 
    
		<!-- HEADER SLIDER ITEM -->
		<div class="sp-slide"> 
			<img class="sp-image" src="css/images/blank.gif" alt="" data-src="images/slide_01.jpg" />
			<div class="container">
				<h3 class="sp-layer slider-welcome" data-position="leftCenter" data-horizontal="15" data-vertical="-370" data-show-transition="left" data-hide-transition="left" data-show-delay="0" data-hide-delay="0"> Welcome Dental Clinic </h3>
				<h1 class="sp-layer slider-title" data-position="leftCenter" data-horizontal="15" data-vertical="-230"  data-show-transition="left" data-hide-transition="left" data-show-delay="200" data-hide-delay="200"> It is quite simple! </h1>
				<h2 class="sp-layer slider-subtitle" data-position="leftCenter" data-horizontal="15" data-vertical="-120" data-show-transition="left" data-hide-transition="left" data-show-delay="400" data-hide-delay="400"> You choose convenient time! </h2>
				<p class="sp-layer slider-text"  data-position="leftCenter" data-horizontal="15" data-vertical="80"  data-show-transition="left" data-hide-transition="left" data-show-delay="600" data-hide-delay="600">  We provide team-based, comprehensive dental care for children and adults, <br>including patients of all ages who are anxious  </p>
				<p class="sp-layer slider-button"  data-position="leftCenter" data-horizontal="15" data-vertical="300"  data-show-transition="left" data-hide-transition="left" data-show-delay="800" data-hide-delay="800"> <a href="#" class="btn btn-primary">READ MORE</a> </p>
			</div>
		</div>
    
		<!-- HEADER SLIDER ITEM -->
		<div class="sp-slide"> 
			<img class="sp-image" src="css/images/blank.gif" alt="" data-src="images/slide_02.jpg" />
			<div class="container">
				<h3 class="sp-layer slider-welcome" data-position="leftCenter" data-horizontal="15" data-vertical="-370" data-show-transition="left" data-hide-transition="left" data-show-delay="0" data-hide-delay="0"> Healthy kids </h3>
				<h1 class="sp-layer slider-title" data-position="leftCenter" data-horizontal="15" data-vertical="-230" data-show-transition="left" data-hide-transition="left" data-show-delay="200" data-hide-delay="200"> Our concern </h1>
				<h2 class="sp-layer slider-subtitle" data-position="leftCenter" data-horizontal="15" data-vertical="-120" data-show-transition="left" data-hide-transition="left" data-show-delay="400" data-hide-delay="400"> Discount for children Rs. 99 /- </h2>
				<p class="sp-layer slider-text" data-position="leftCenter" data-horizontal="15" data-vertical="80" data-show-transition="left" data-hide-transition="left" data-show-delay="600" data-hide-delay="600">  We provide team-based, comprehensive dental care for children and adults, <br>including patients of all ages who are anxious  </p>
				<p class="sp-layer slider-button" data-position="leftCenter" data-horizontal="15" data-vertical="300" data-show-transition="left" data-hide-transition="left" data-show-delay="800" data-hide-delay="800"> <a href="#" class="btn btn-primary">READ MORE</a> </p>
			</div>
		</div>
    
		<!-- HEADER SLIDER ITEM -->
		<div class="sp-slide"> 
			<img class="sp-image" src="css/images/blank.gif" alt="" data-src="images/slide_03.jpg" />
			<div class="container">
				<h3 class="sp-layer slider-welcome" data-position="leftCenter" data-horizontal="15" data-vertical="-370" data-show-transition="left" data-hide-transition="left" data-show-delay="0" data-hide-delay="0"> A beautiful smile is our task! </h3>
				<h1 class="sp-layer slider-title" data-position="leftCenter" data-horizontal="15" data-vertical="-230" data-show-transition="left" data-hide-transition="left" data-show-delay="200" data-hide-delay="200"> Dental services </h1>
				<h2 class="sp-layer slider-subtitle" data-position="leftCenter" data-horizontal="15" data-vertical="-120" data-show-transition="left" data-hide-transition="left" data-show-delay="400" data-hide-delay="400"> Healthy teeth - healthy body </h2>
				<p class="sp-layer slider-text" data-position="leftCenter" data-horizontal="15" data-vertical="80" data-show-transition="left" data-hide-transition="left" data-show-delay="600" data-hide-delay="600"> We provide team-based, comprehensive dental care for children and adults, <br>including patients of all ages who are anxious  </p>
				<p class="sp-layer slider-button" data-position="leftCenter" data-horizontal="15" data-vertical="300" data-show-transition="left" data-hide-transition="left" data-show-delay="800" data-hide-delay="800"> <a href="#" class="btn btn-primary">READ MORE</a> </p>
			</div>
		</div>
		
	</div>
</div>
<!-- =========================
     END HEADER SLIDER
============================== --> 
<div class="serv">
	<div class="container">
		<div class="row">
			<div class="serv-items" id="isotope-items" style="position: relative; height: 764.953px;">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 serv-item isotope-item bleaching" style="position: absolute; left: 0px; top: 40px;">
					<div class="serv-item-image"> <img src="images/image 1.jpg" alt=""> </div>
					<div class="serv-item-text">
						<h3>Teeth Whitening</h3>
						<p>Your teeth may become discolored due to various foods, drinks, tobacco products, aging, trauma, or certain medications. Dental whitening (bleaching) is one of the primary treatments used to address these discolorations.Dental whitening is a straightforward process. Whitening products contain one of two tooth whiteners (hydrogen peroxide or carbamide peroxide). These bleaching agents break down stains into smaller pieces, making the colors less concentrated and giving your teeth a brighter appearance.</p>
						<div class="serv-item-button"> 
							<div class="serv-item-tag">Teeth Whitening</div>
						</div>
					</div>
				</div>
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 serv-item isotope-item estetik" style="position: absolute; left: 0px; top: 398px;">
					<div class="serv-item-image"> <img src="images/image 2.jpg" alt=""> </div>
					<div class="serv-item-text">
						<h3>Simple Extraction of Teeth</h3>
						<p>A dental extraction (also referred to as tooth extraction, exodontia, exodontics, or informally, tooth pulling) is the removal of teeth from the dental alveolus (socket) in the alveolar bone. Extractions are performed for a wide variety of reasons, but most commonly to remove teeth which have become unrestorable through tooth decay, periodontal disease, or dental trauma, especially when they are associated with toothache. Sometimes impacted wisdom teeth (wisdom teeth that are stuck and unable to grow normally into the mouth) cause recurrent infections of the gum (pericoronitis), and may be removed when other conservative treatments have failed (cleaning, antibiotics and operculectomy). </p>
						<div class="serv-item-button">
							<div class="serv-item-tag">Simple Extraction of Teeth</div>
						</div>
					</div>
				</div>
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 serv-item isotope-item cerrahi" style="position: absolute; left: 0px; top: 785px;">
					<div class="serv-item-image"> <img src="images/image3.jpg" alt=""> </div>
					<div class="serv-item-text">
						<h3>Surgica removal of Impacted teeth</h3>
						<p>Impacted wisdom teeth is a condition where the third molars (wisdom teeth) are prevented from erupting into the mouth.[1] This can be caused by a physical barrier, such as other teeth, or when the tooth is angled away from a vertical position.[2] Completely unerupted wisdom teeth usually result in no symptoms, although they can sometimes develop cysts or neoplasms. Partially erupted wisdom teeth or wisdom teeth that are not erupted but are exposed to oral bacteria through deep periodontal pocket, can develop cavities or pericoronitis.</p>
						<div class="serv-item-button">
							<div class="serv-item-tag">Surgica removal of Impacted teeth</div>
						</div>
					</div>
				</div>

				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 serv-item isotope-item protez" style="position: absolute; left: 0px; top: 1172px;">
					<div class="serv-item-image"> <img src="images/image 4.jpg" alt=""> </div>
					<div class="serv-item-text">
						<h3>Removal of Cysts& Tumors</h3>
						<p>A dentigerous cyst, also known as a follicular cyst, is an epithelial-lined developmental cyst formed by accumulation of fluid between the reduced enamel epithelium and the crown of an unerupted tooth.[2][3][4] It is formed when there is an alteration in the reduced enamel epithelium and encloses the crown of an unerupted tooth at the cemento-enamel junction. Fluid is accumulated between reduced enamel epithelium and the crown of an unerupted tooth.Dentigerous cysts are the second[5] most prevalent type of odontogenic cysts after radicular cyst. Seventy percent of the cases occur in the mandible. Dentigerous cysts are usually painless. The patient usually comes with a concern of delayed tooth eruption or facial swelling. </p>
						<div class="serv-item-button">
							<div class="serv-item-tag">Removal of Cysts& Tumors</div>
						</div>
					</div>
				</div>

				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 serv-item isotope-item implant" style="position: absolute; left: 0px; top: 40px;">
					<div class="serv-item-image"> <img src="images/image5.jpg" alt=""> </div>
					<div class="serv-item-text">
						<h3>Fracture jaw Bones</h3>
						<p>Mandibular fracture, also known as fracture of the jaw, is a break through the mandibular bone. In about 60% of cases the break occurs in two places.[1] It may result in a decreased ability to fully open the mouth.[1] Often the teeth will not feel properly aligned or there may be bleeding of the gums.[1] Mandibular fractures occur most commonly among males in their 30s.[1]Mandibular fractures are typically the result of trauma.[1] This can include a fall onto the chin or a hit from the side.[1] Rarely they may be due to osteonecrosis or tumors in the bone.[1] The most common area of fracture is at the condyle (36%), body (21%), angle (20%) and symphysis (14%).[1] Rarely the fracture may occur at the ramus (3%) or coronoid process (2%). While a diagnosis can occasionally be made with plain X-ray, modern CT scans are more accurate.[1]</p>
						<div class="serv-item-button">
							<div class="serv-item-tag">Fracture jaw Bones</div>
						</div>
					</div>
				</div>

				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 serv-item isotope-item ortodontik" style="position: absolute; left: 0px; top: 2045px;">
					<div class="serv-item-image"> <img src="images/image6.jpg" alt=""> </div>
					<div class="serv-item-text">
						<h3>Cosmetic Procedures</h3>
						<p>Cosmetic dentistry is generally used to refer to any dental work that improves the appearance (though not necessarily the functionality) of teeth, gums and/or bite. It primarily focuses on improvement in dental aesthetics in color, position, shape, size, alignment and overall smile appearance.[1] Many dentists refer to themselves as "cosmetic dentists" regardless of their specific education, specialty, training, and experience in this field. This has been considered unethical with a predominant objective of marketing to patients.[2] The American Dental Association does not recognize cosmetic dentistry as a formal specialty area of dentistry.[3]</p>
						<div class="serv-item-button">
							<div class="serv-item-tag">Cosmetic Procedures</div>
						</div>
					</div>
				</div>
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 serv-item isotope-item periodontoloji" style="position: absolute; left: 0px; top: 2390px;">
					<div class="serv-item-image"> <img src="images/image7.jpg" alt=""> </div>
					<div class="serv-item-text">
						<h3>Implants</h3>
						<p>A dental implant is a prosthesis that interfaces with the bone of the jaw or skull to support a dental prosthesis such as a crown, bridge, denture, or facial prosthesis or to act as an orthodontic anchor. The basis for modern dental implants is a biological process called osseointegration, in which materials such as titanium or zirconia form an intimate bond to the bone.The implant fixture is first placed so that it is likely to osseointegrate, then a dental prosthetic is added. A variable amount of healing time is required for osseointegration before either the dental prosthetic is attached to the implant or an abutment is placed which will hold a dental crown.</p>
						<div class="serv-item-button">
							<div class="serv-item-tag">Implants</div>
						</div>
					</div>
				</div>
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 serv-item isotope-item cerrahi" style="position: absolute; left: 0px; top: 2777px;">
					<div class="serv-item-image"> <img src="images/image8.jpg" alt=""> </div>
					<div class="serv-item-text">
						<h3>Removable Dentures and Fixed Teeth</h3>
						<p>Dentures (also known as false teeth) are prosthetic devices constructed to replace missing teeth, supported by the surrounding soft and hard tissues of the oral cavity. Conventional dentures are removable (removable partial denture or complete denture). However, there are many denture designs, some of which rely on bonding or clasping onto teeth or dental implants (fixed prosthodontics). There are two main categories of dentures, the distinction being whether they fit onto the mandibular arch or on the maxillary arch.</p>
						<div class="serv-item-button"> 
							<div class="serv-item-tag">Removable Dentures and Fixed Teeth</div>
						</div>
					</div>
				</div>
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 serv-item isotope-item radyoloji" style="position: absolute; left: 0px; top: 3136px;">
					<div class="serv-item-image"> <img src="images/image9.jpg" alt=""> </div>
					<div class="serv-item-text">
						<h3>Root Canal Treatment</h3>
						<p>Root canal treatment (also known as endodontic therapy, endodontic treatment, root canal therapy) is a treatment sequence for the infected pulp of a tooth which is intended to result in the elimination of infection and the protection of the decontaminated tooth from future microbial invasion.Root canals, and their associated pulp chamber, are the physical hollows within a tooth that are naturally inhabited by blood vessels.</p>
						<div class="serv-item-button"> 
							<div class="serv-item-tag">Root Canal Treatment</div>
						</div>
					</div>
				</div>
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 serv-item isotope-item estetik" style="position: absolute; left: 0px; top: 3495px;">
					<div class="serv-item-image"> <img src="images/image10.jpg" alt=""> </div>
					<div class="serv-item-text">
						<h3>Cleaning and Flap Surgery</h3>
						<p>Flap surgery is sometimes performed to remove tartar deposits in deep pockets make it easier for you or your dental professional to keep the area clean. This common surgery involves lifting back the gums and removing the tartar.
						Teeth cleaning is part of oral hygiene and involves the removal of dental plaque from teeth with the intention of preventing cavities gingivitis. People routinely clean their own teeth by brushing and interdental cleaning, and dental hygienists can remove hardened deposits not removed by routine cleaning. </p>
						<div class="serv-item-button"> 
							<div class="serv-item-tag">Cleaning and Flap Surgery</div>
						</div>
					</div>
				</div>
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 serv-item isotope-item radyoloji" style="position: absolute; left: 0px; top: 3136px;">
					<div class="serv-item-image"> <img src="images/image11.jpg" alt=""> </div>
					<div class="serv-item-text">
						<h3>Correction of Irregularly placed teeth using braces</h3>
						<p>Dental braces (also known as braces, orthodontic cases, or cases) are devices used in orthodontics that align and straighten teeth and help position them with regard to a person's bite, while also aiming to improve dental health. They are often used to correct underbites, as well as malocclusions, overbites, open bites, gaps, deep bites, cross bites, crooked teeth, and various other flaws of the teeth and jaw. Braces can be either cosmetic or structural. Dental braces are often used in conjunction with other orthodontic appliances to help widen the palate or jaws and to otherwise assist in shaping the teeth and jaws.</p>
						<div class="serv-item-button"> 
							<div class="serv-item-tag">Correction of Irregularly placed teeth using braces</div>
						</div>
					</div>
				</div>
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 serv-item isotope-item radyoloji" style="position: absolute; left: 0px; top: 3136px;">
					<div class="serv-item-image"> <img src="images/image12.jpg" alt=""> </div>
					<div class="serv-item-text">
						<h3>Treatment for child teeth</h3>
						<p>Deciduous teeth or primary teeth, also informally known as baby teeth, tothlings, milk teeth, or temporary teeth,[1] are the first set of teeth in the growth and development of humans and other diphyodonts, which include most mammals but not elephants, kangaroos, or manatees, which are polyphyodonts. Deciduous teeth develop during the embryonic stage of development and erupt (break through the gums and become visible in the mouth) during infancy. They are usually lost and replaced by permanent teeth, but in the absence of their permanent replacements, they can remain functional for many years into adulthood.</p>
						<div class="serv-item-button"> 
							<div class="serv-item-tag">Treatment for child teeth</div>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>
</div>

<!-- =========================
    FOOTER
============================== -->
<div class="footer">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 footer-matchheight">
        <div class="row"> 
          
          <!-- FOOTER ITEM 1 -->
          <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 footer-item footer-item-1">
            <h3 class="footer-title footer-title-line"> About Us</h3>
            <div class="tweet">
              <div class="tweet-login"> <a href="#" style="font-size:20px;">SAMPREETH DENTAL CLINIC</a> </div>
              <div class="tweet-text"><p style="font-size:15px"> We provide team-based, comprehensive dental care for children and adults, including patients of all ages who are anxious or have an underlying developmental or medical condition that may add complexity to the management of their oral health.</p></div>
              <!-- <div class="tweet-date"> 03.10.2016 </div> -->
            </div>
            <!-- <div class="tweet"> -->
              <!-- <div class="tweet-login"> <a href="#">@DentalClinic</a> </div> -->
              <!-- <div class="tweet-text"> Lorem ipsum dolro lobortis quobortisnissim pulvinar ac Lorem. </div> -->
              <!-- <div class="tweet-date"> 03.10.2016 </div> -->
            <!-- </div> -->
            <!-- <div class="tweet"> -->
              <!-- <div class="tweet-login"> <a href="#">@DentalClinic</a> </div> -->
              <!-- <div class="tweet-text"> Lorem ipsum dolro lobortis quobortisnissim pulvinar ac Lorem. </div> -->
              <!-- <div class="tweet-date"> 03.10.2016 </div> -->
            <!-- </div> -->
          </div>
          
          <!-- FOOTER ITEM 2 -->
          <div class="col-lg-8 col-md-6 col-sm-6 col-xs-12 footer-item footer-item-2">
            <h3 class="footer-title footer-title-line"><i class="fa fa-clock-o"></i> OPENING HOURS</h3>
            <div class="opening-left"> Monday<br>
              Tuesday<br>
              Wednesday<br>
              Thursday<br>
              Friday<br>
              Saturday<br>
              Sunday </div>
            <div class="opening-right"> 
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM
            </div>
          </div>
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 footer-copyright">
            <div> Copyright &copy; 2026 SAMPREETH DENTAL CLINIC | Powerb by <a href="https://sab-it.co" target="_blank">SAB IT SERVICES</a> </div>
          </div>
        </div>
      </div>
      
      <!-- FOOTER ITEM 3 -->
	   <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 footer-item  footer-matchheight" id="footer-item-3">
      <!-- <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 footer-item footer-item-3 footer-matchheight" id="footer-item-3"> -->
        <h3 class="footer-title"><i class="fa fa-map-marker"></i> CONTACTS</h3>
        <div class="footer-item-3-phone"> <i class="fa fa-phone"></i> <a href="tel:+917995605888">+91 79956 05888</a> </div>
        <div class="footer-item-3-location"> <i class="flaticon-navigation-arrow"></i> #57-6-2, Venkata Sai Enclave, Old Post Office Road, Opp:Sri Chaitanya English Medium High School, Patamata, Vijayawada - 10.</div>
        <div class="footer-item-3-mail"> 
			<i class="fa fa-envelope"></i> <a href="#">drnadellaneelima@gmail.com</a> 
		</div>
        <div class="footer-item-3-socials"> 
			<a href="#"><i class="fa fa-facebook"></i></a> 
			<a href="#"><i class="fa fa-google-plus"></i></a> 
			<a href="#"><i class="fa fa-twitter"></i></a> 
			<a href="#"><i class="fa fa-skype"></i></a> </div>
      </div>
      
      <!-- FOOTER ITEM 4 -->
      <!-- <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 footer-item footer-item-4 footer-matchheight" id="footer-item-4"> </div> -->
    </div>
  </div>
</div>
<!-- =========================
    END FOOTER
============================== --> 

<!-- =========================
    POPUP FORMS
============================== -->
<div class="bookform bookform-1" id="bookform1">
	<div class="bookform-left">
		<h2 class="section-title"><span class="bold700">BOOK APPOINTMENT</span></h2>
		<form>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item f-doctor">
					<select id="form-doctor" class="form-doctor" name="form-doctor">
						<option value="1" selected="selected">Select doctor</option>
						<option value="2">Dr Nadella Koteswara Rao</option>
						<option value="3">Dr Nadella Neelima</option>
						<option value="4">Dr Kiran Kumar Dodda</option>
						<option value="5">Dr Srikanth Koya</option>
						<option value="6">Dr Ravi Kiran V</option>
						<option value="7">Dr Satya Karthik M</option>
						<option value="8">Dr Prasanna</option>
					</select>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item name">
					<input type="text" name="name1" id="name1" data-validation="required" placeholder="Your name" />
					<div class="help help-sm help-red">!</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item phone">
					<input type="text" name="phone1" id="phone1" data-validation="required" placeholder="Phone" />
					<div class="help help-sm help-red">!</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item email">
					<input type="text" name="email1" id="email1" placeholder="E-mail" />
				</div>
			</div>
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item date">
					<input type="text" class="datepicker-f" id="datepicker1" name="date1" data-validation="required" placeholder="Date" />
					<div class="help help-sm help-red">!</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item time-f">
					<input type="text" class="timepicker-f" id="timepicker1" name="time1" data-validation="required" placeholder="Time" />
					<div class="help help-sm help-red">!</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
					<textarea name="message1" id="message1" placeholder="Your message.."></textarea>
				</div>
			</div>
			<div class="row" style="display:none;">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item honeypot">
					<label class="fl_label">Honeypot:</label>
					<input type="text" name="last" value="" class="form-control fl_input">
				</div>
			</div>
			<div class="row latest-row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
					<button class="btn btn-primary">SUBMIT</button>
					<a class="fb-close" id="fb-close1" href="javascript:jQuery.fancybox.close();">Cancel</a>
				</div>
			</div>
		</form>
	</div>
	<div class="bookform-right">
		<div class="bookform-right-info-1">
			<h5>Please select a doctor</h5>
			Some Content Goes Here 
		</div>
		<div class="bookform-right-info-2"> Some Content Goes Here </div>
	</div>
	<div class="bookform-right">
		<div class="doctor-info">
			<div class="doctor-info-image"> <img src="images/doctor01.jpg" alt="" /> </div>
			<div class="doctor-info-name"> Dr Nadella Koteswara Rao </div>
			<div class="doctor-info-position"> Oral& Maxillofacial Surgeon </div>
			<div class="doctor-info-hours-title"> OPENING HOURS </div>
			<div class="doctor-info-hours">
				<div class="doctor-info-hours-clock"> <img src="images/clock.png" alt="" /> </div>
				<div class="doctor-info-hours-left"> 
					Monday<br>
					Tuesday<br>
					Wednesday<br>
					Thursday<br>
					Friday<br>
					Saturday<br>
					Sunday 
				</div>
				<div class="doctor-info-hours-right"> Closed<br>
					10:00 am - 9:00 pm<br>
					10:00 am - 9:00 pm<br>
					10:00 am - 9:00 pm<br>
					10:00 am - 9:00 pm<br>
					10:00 am - 9:00 pm<br>
					10:00 am - 1:00 pm
				</div>
			</div>
			<div class="doctor-info-desc"> 
				
			</div>
		</div>
	</div>
</div>
	
<div class="bookform" id="bookform2">
  <div class="bookform-left">
	<h2 class="section-title">
	  <span class="bold700">
		BOOK APPOINTMENT
	  </span>
	</h2>
	<form>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item name">
		  <input type="text" name="name6" id="name6" data-validation="required" placeholder="Your name" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item phone">
		  <input type="text" name="phone6" id="phone6" data-validation="required" placeholder="Phone" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item email">
		  <input type="text" name="email6" id="email6" placeholder="E-mail" />
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item date">
		  <input type="text" class="datepicker-f" id="datepicker6" name="date6" data-validation="required" placeholder="Date" />
		  <div class="help help-sm help-red">!</div>
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item time-f">
		  <input type="text" class="timepicker-f" id="timepicker6" name="time6" data-validation="required" placeholder="Time" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
		  <textarea name="message6" id="message6" placeholder="Your message.."></textarea>
		</div>
	  </div>
	  <div class="row" style="display:none;">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item honeypot">
		  <label class="fl_label" >Honeypot:</label>
		  <input type="text" name="last" value="" class="form-control fl_input">
		</div>
	  </div>
	  <div class="row latest-row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
		  <button class="btn btn-primary">
			SUBMIT
		  </button>
		  <a class="fb-close" id="fb-close6" href="javascript:jQuery.fancybox.close();">Cancel</a> </div>
	  </div>
	</form>
  </div>
  <div class="bookform-right">
	<div class="doctor-info">
	  <div class="doctor-info-image"> <img src="images/doctor01.jpg" alt="" /> </div>
	  <div class="doctor-info-name"> Dr Nadella Koteswara Rao </div>
	  <div class="doctor-info-position"> Oral& Maxillofacial Surgeon </div>
	  <div class="doctor-info-hours-title"> OPENING HOURS </div>
	  <div class="doctor-info-hours">
		<div class="doctor-info-hours-clock"> <img src="images/clock.png" alt="" /> </div>
		<div class="doctor-info-hours-left"> Monday<br>
		  Tuesday<br>
		  Wednesday<br>
		  Thursday<br>
		  Friday<br>
		  Saturday<br>
		  Sunday </div>
		<div class="doctor-info-hours-right"> Closed<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 1:00 pm </div>
	  </div>
	  <div class="doctor-info-desc"> </div>
	</div>
  </div>
</div>

<div class="bookform" id="bookform3">
  <div class="bookform-left">
	<h2 class="section-title">
	  <span class="bold700">
		BOOK APPOINTMENT
	  </span>
	</h2>
	<form>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item name">
		  <input type="text" name="name6" id="name6" data-validation="required" placeholder="Your name" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item phone">
		  <input type="text" name="phone6" id="phone6" data-validation="required" placeholder="Phone" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item email">
		  <input type="text" name="email6" id="email6" placeholder="E-mail" />
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item date">
		  <input type="text" class="datepicker-f" id="datepicker6" name="date6" data-validation="required" placeholder="Date" />
		  <div class="help help-sm help-red">!</div>
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item time-f">
		  <input type="text" class="timepicker-f" id="timepicker6" name="time6" data-validation="required" placeholder="Time" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
		  <textarea name="message6" id="message6" placeholder="Your message.."></textarea>
		</div>
	  </div>
	  <div class="row" style="display:none;">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item honeypot">
		  <label class="fl_label" >Honeypot:</label>
		  <input type="text" name="last" value="" class="form-control fl_input">
		</div>
	  </div>
	  <div class="row latest-row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
		  <button class="btn btn-primary">
			SUBMIT
		  </button>
		  <a class="fb-close" id="fb-close6" href="javascript:jQuery.fancybox.close();">Cancel</a> </div>
	  </div>
	</form>
  </div>
  <div class="bookform-right">
	<div class="doctor-info">
	  <div class="doctor-info-image"> <img src="images/doctor02.jpg" alt="" /> </div>
	  <div class="doctor-info-name"> Dr Nadella Neelima </div>
	  <div class="doctor-info-position"> Dental Surgeon </div>
	  <div class="doctor-info-hours-title"> OPENING HOURS </div>
	  <div class="doctor-info-hours">
		<div class="doctor-info-hours-clock"> <img src="images/clock.png" alt="" /> </div>
		<div class="doctor-info-hours-left"> Monday<br>
		  Tuesday<br>
		  Wednesday<br>
		  Thursday<br>
		  Friday<br>
		  Saturday<br>
		  Sunday </div>
		<div class="doctor-info-hours-right"> Closed<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 1:00 pm </div>
	  </div>
	  <div class="doctor-info-desc"> </div>
	</div>
  </div>
</div>
<!-- =========================
    END POPUP FORMS
============================== -->

<div class="totop" id="totop"> <i class="fa fa-angle-up"></i> </div>

<!-- =========================
    COLOR SWITHER
============================== -->
<!-- <div class="color-sw-open" id="color-sw-open"> <i class="fa fa-gear"></i> </div> -->
<!-- <div class="color-sw" id="color-sw"> -->
  <!-- <div class="color-sw-header"> Style switcher -->
    <!-- <span class="color-sw-close" id="color-sw-close"> -->
      <!-- <i class="fa fa-close"></i> -->
    <!-- </span> -->
  <!-- </div> -->
  <!-- <div class="color-sw-body"> -->
    <!-- <p>Choose color style</p> -->
    <!-- <div class="color-sw-item active" id="blue"> -->
      <!-- <div></div> -->
    <!-- </div> -->
    <!-- <div class="color-sw-item" id="violet"> -->
      <!-- <div></div> -->
    <!-- </div> -->
    <!-- <div class="color-sw-item" id="red"> -->
      <!-- <div></div> -->
    <!-- </div> -->
    <!-- <div class="color-sw-item" id="green"> -->
      <!-- <div></div> -->
    <!-- </div> -->
  <!-- </div> -->
<!-- </div> -->
<!-- =========================
    END COLOR SWITHER
============================== -->

<link rel="stylesheet" type="text/css" href="css/responsive.css" />

<!-- =========================
     SCRIPTS   
============================== --> 
<!-- JQUERY --> 
<script src="js/jquery-2.2.0.min.js"></script> 

<!-- BOOTSTRAP --> 
<script src="js/bootstrap.min.js"></script> 

<!-- SLIDER PRO --> 
<script src="js/jquery.sliderPro.min.js"></script> 

<!-- LIGHTBOX --> 
<script src="js/jquery.fancybox.pack.js"></script> 

<!-- CAROUSEL --> 
<script src="js/owl.carousel.js"></script> 

<!-- STAR RATING --> 
<script src="js/jquery.barrating.min.js"></script> 

<!-- ISOTOPE FILTER --> 
<script src="js/isotope.pkgd.min.js"></script> 

<!-- SCROLLSPY --> 
<script src="js/scrollspy.js"></script> 

<!-- DATEPICKER --> 
<script src="js/moment.js"></script> 
<script src="js/bootstrap-datetimepicker.min.js"></script> 

<!-- FORM VALIDATOR --> 
<script src="js/jquery.form-validator.js"></script> 

<!-- SELECT STYLING --> 
<script src="js/jquery.selectBox.js"></script> 

<!-- MATCHHEIGHT --> 
<script src="js/jquery.matchHeight.js"></script> 

<!-- JQUERY FORM --> 
<script src="js/jquery.form.html"></script> 

<!-- IMAGES LOADED --> 
<script src="js/imagesloaded.pkgd.min.js"></script> 

<!-- CUSTOM SCRIPT --> 
<script src="js/theme.js"></script> 

<!-- GOOGLE MAPS --> 
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCIt0-3xYygh5jhA2YCRcEP9YsLO3mw0co&amp;language=en&amp;amp&amp;sensor=true"></script> 
</body>
</html>