<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Specialized dental care to straighten crooked teeth in children and adults. Treat diseases of the gums and the placement of dental implants.">
<meta name="keywords" content="Sampreeth Dental Clinic, Vijayawada Dental Clinic, Top 10 Dental Doctors in Vijayawada, Most Rated Dental Doctor in vijayawada">
<meta name="author" content="Sampreeth Dental Clinc">

<!-- SITE TITLE -->
<title>Sampreeth Dental Clinc | Vijayawada, Andhra Pradesh</title>

<!-- =========================
      FAV AND TOUCH ICONS  
============================== -->
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="apple-touch-icon" href="images/apple-touch-icon.html">
<link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.html">
<link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.html">

<!-- =========================
     STYLESHEETS   
============================== -->

<link rel="stylesheet" type="text/css" href="css/master.css" />
</head>

<body data-spy="scroll" data-target=".navbar">
	<div class="preloader" id="preloader"> 
		<img src="images/preloader.gif" alt="" /> 
	</div>

<!-- =========================
     TOP BAR
============================== -->
<div class="top-bar" id="top-bar">
  <div class="container">
    <div class="row"> 
      
      <!-- TOP BAR LEFT -->
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
        <div class="top-bar-adress"> <i class="flaticon-navigation-arrow"></i> #57-6-2, Venkata Sai Enclave, Opp:Sri Chaitanya English Medium High School, Patamata, Vijayawada. </div>
      </div>
      
      <!-- TOP BAR RIGHT -->
      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
        <div class="top-bar-social"> 
            <a href="#"><i class="fa fa-facebook"></i></a> 
            <a href="#"><i class="fa fa-google-plus"></i></a> 
            <a href="#"><i class="fa fa-twitter"></i></a> 
            <a href="#"><i class="fa fa-skype"></i></a> </div>
        <div class="top-bar-mail"> <i class="fa fa-envelope"></i> <a href="mailto:drnadellaneelima@gmail.com">drnadellaneelima@gmail.com</a> </div>
      </div>
    </div>
  </div>
</div>
<!-- =========================
     END TOP BAR   
============================== --> 

<!-- =========================
     HEADER
============================== -->
<div class="header" id="header">
  <div class="container">
    <div class="row"> 
      
      <!-- HEADER LOGO -->
      <div class="col-lg-6 col-md-6 col-sm-5 col-xs-12">
        <div class="header-logo"> 
            <a href="index.php">
                <img src="img/lg.jpg" alt=""/>
                <span class="bold600 color-child-6">SAMPREETH</span>
                <span class="color-child-5">DENTAL CLINIC</span>
            </a> 
        </div>
      </div>
      
      <!-- HEADER BUTTONS -->
      <div class="col-lg-6 col-md-6 col-sm-7 col-xs-12">
        <div class="header-button"> <a href="#bookform1" class="fancybox-2 btn btn-default">
            <span class="plus">+</span>MAKE AN APPOINTMENT</a> 
		</div>
        <div class="header-phone"> 
			<i class="fa fa-phone"></i> <a href="tel:+917995605888">+91 79956 05888</a>
		</div>
      </div>
    </div>
  </div>
</div>
<!-- =========================
     END HEADER
============================== --> 

<!-- =========================
     MAIN MENU
============================== -->
<div class="top-menu" id="top-menu">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="mobile-bar-cont">
          <div class="top-menu-logo"> <a href="index.php"><img src="img/lg.jpg" alt="" />
              <span class="bold600 color-child-6">
                SAMPREETH
              </span>
              <span class="color-child-5">
                DENTAL CLINIC
              </span>
            </a> </div>
          <div class="mobile-bar">
            <div class="show-menu" id="show-menu"> <i class="fa fa-bars"></i> </div>
            <div class="color-sw-open-1" id="color-sw-open-1"> <i class="fa fa-gear"></i> </div>
          </div>
        </div>
        <ul class="nav navbar-nav">
          <li class="active"><a href="index.php">HOME</a></li>
          <li><a href="about.php">ABOUT US</a></li>
          <li class="dropdown"> <a data-toggle="dropdown" href="">TREATMENTS</a>
            <ul class="dropdown-menu " role="menu">              
				<li><a href="services.php">Teeth whitening</a></li> 
				<li><a href="services.php">Simple Extraction of teeth</a></li> 
				<li><a href="services.php">Surgical removal of Impacted teeth</a></li> 
				<li><a href="services.php">Removal of Cysts& Tumours</a></li> 
				<li><a href="services.php">Fracture Jaw bones</a></li> 
				<li><a href="services.php">Cosmetic Procedures</a></li> 
				<li><a href="services.php">Implants</a></li> 
				<li><a href="services.php">Removable Dentures& Fixed teeth</a></li> 
				<li><a href="services.php">Root canal Treatments</a></li> 
				<li><a href="services.php">Cleaning & Flap Surgeries</a></li> 
				<li><a href="services.php">Correction of Irregular placed Teeth using Braces</a></li> 
				<li><a href="services.php">Treatment for Child Teeth</a></li> 
            </ul>
          </li>
          <!-- <li class="dropdown"> <a data-toggle="dropdown" href="#">OUR DOCTORS</a> -->
            <!-- <ul class="dropdown-menu" role="menu"> -->
              <!-- <li><a href="doctors.html">Our doctors</a></li> -->
              
            <!-- </ul> -->
          <!-- </li> -->
         
		  <li><a href="gallery.php">GALLERY</a></li>
          <!-- <li class="dropdown"> <a data-toggle="dropdown" href="#">PAGES</a> -->
            <!-- <ul class="dropdown-menu" role="menu"> -->
              <!-- <li><a href="gallery1.html">Gallery 1</a></li> -->
              <!-- <li><a href="gallery2.html">Gallery 2</a></li> -->
              <!-- <li><a href="prices.html">Prices</a></li> -->
              <!-- <li><a href="timetable.html">Timetable</a></li> -->
              <!-- <li><a href="payment.html">Payments</a></li> -->
              <!-- <li><a href="404.html">404 Page</a></li> -->
            <!-- </ul> -->
          <!-- </li> -->
          <li><a href="contact.php">CONTACT US</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
<!-- =========================
     END MAIN MENU
============================== --> 

<!-- =========================
     HEADER SLIDER
============================== -->
<div id="slider" class="slider">
	<div class="sp-slides"> 
    
		<!-- HEADER SLIDER ITEM -->
		<div class="sp-slide"> 
			<img class="sp-image" src="css/images/blank.gif" alt="" data-src="images/slide_01.jpg" />
			<div class="container">
				<h3 class="sp-layer slider-welcome" data-position="leftCenter" data-horizontal="15" data-vertical="-370" data-show-transition="left" data-hide-transition="left" data-show-delay="0" data-hide-delay="0"> Welcome Dental Clinic </h3>
				<h1 class="sp-layer slider-title" data-position="leftCenter" data-horizontal="15" data-vertical="-230"  data-show-transition="left" data-hide-transition="left" data-show-delay="200" data-hide-delay="200"> It is quite simple! </h1>
				<h2 class="sp-layer slider-subtitle" data-position="leftCenter" data-horizontal="15" data-vertical="-120" data-show-transition="left" data-hide-transition="left" data-show-delay="400" data-hide-delay="400"> You choose convenient time! </h2>
				<p class="sp-layer slider-text"  data-position="leftCenter" data-horizontal="15" data-vertical="80"  data-show-transition="left" data-hide-transition="left" data-show-delay="600" data-hide-delay="600">  We provide team-based, comprehensive dental care for children and adults, <br>including patients of all ages who are anxious  </p>
				<p class="sp-layer slider-button"  data-position="leftCenter" data-horizontal="15" data-vertical="300"  data-show-transition="left" data-hide-transition="left" data-show-delay="800" data-hide-delay="800"> <a href="#" class="btn btn-primary">READ MORE</a> </p>
			</div>
		</div>
    
		<!-- HEADER SLIDER ITEM -->
		<div class="sp-slide"> 
			<img class="sp-image" src="css/images/blank.gif" alt="" data-src="images/slide_02.jpg" />
			<div class="container">
				<h3 class="sp-layer slider-welcome" data-position="leftCenter" data-horizontal="15" data-vertical="-370" data-show-transition="left" data-hide-transition="left" data-show-delay="0" data-hide-delay="0"> Healthy kids </h3>
				<h1 class="sp-layer slider-title" data-position="leftCenter" data-horizontal="15" data-vertical="-230" data-show-transition="left" data-hide-transition="left" data-show-delay="200" data-hide-delay="200"> Our concern </h1>
				<h2 class="sp-layer slider-subtitle" data-position="leftCenter" data-horizontal="15" data-vertical="-120" data-show-transition="left" data-hide-transition="left" data-show-delay="400" data-hide-delay="400"> Discount for children Rs. 99 /- </h2>
				<p class="sp-layer slider-text" data-position="leftCenter" data-horizontal="15" data-vertical="80" data-show-transition="left" data-hide-transition="left" data-show-delay="600" data-hide-delay="600">  We provide team-based, comprehensive dental care for children and adults, <br>including patients of all ages who are anxious  </p>
				<p class="sp-layer slider-button" data-position="leftCenter" data-horizontal="15" data-vertical="300" data-show-transition="left" data-hide-transition="left" data-show-delay="800" data-hide-delay="800"> <a href="#" class="btn btn-primary">READ MORE</a> </p>
			</div>
		</div>
    
		<!-- HEADER SLIDER ITEM -->
		<div class="sp-slide"> 
			<img class="sp-image" src="css/images/blank.gif" alt="" data-src="images/slide_03.jpg" />
			<div class="container">
				<h3 class="sp-layer slider-welcome" data-position="leftCenter" data-horizontal="15" data-vertical="-370" data-show-transition="left" data-hide-transition="left" data-show-delay="0" data-hide-delay="0"> A beautiful smile is our task! </h3>
				<h1 class="sp-layer slider-title" data-position="leftCenter" data-horizontal="15" data-vertical="-230" data-show-transition="left" data-hide-transition="left" data-show-delay="200" data-hide-delay="200"> Dental services </h1>
				<h2 class="sp-layer slider-subtitle" data-position="leftCenter" data-horizontal="15" data-vertical="-120" data-show-transition="left" data-hide-transition="left" data-show-delay="400" data-hide-delay="400"> Healthy teeth - healthy body </h2>
				<p class="sp-layer slider-text" data-position="leftCenter" data-horizontal="15" data-vertical="80" data-show-transition="left" data-hide-transition="left" data-show-delay="600" data-hide-delay="600"> We provide team-based, comprehensive dental care for children and adults, <br>including patients of all ages who are anxious  </p>
				<p class="sp-layer slider-button" data-position="leftCenter" data-horizontal="15" data-vertical="300" data-show-transition="left" data-hide-transition="left" data-show-delay="800" data-hide-delay="800"> <a href="#" class="btn btn-primary">READ MORE</a> </p>
			</div>
		</div>
		
	</div>
</div>
<!-- =========================
     END HEADER SLIDER
============================== --> 
<div class="page-title page-title-contacts bg-pattern" data-bgcolor="3B4B89">
  <div class="page-title-overlay">
    <div class="container">
      <h1>CONTACT US</h1>
      <p>Our Clinic has grown to provide a world class facility for the treatment of tooth loss, dental cosmetics and advanced restorative dentistry.</p>
    </div>
  </div>
</div>
<div class="breadcrumbs">
  <div class="container">
    <div class="row">
      <ol class="breadcrumb">
        <li class="breadcrumb-home"><a href="#"><i class="fa fa-home"></i></a></li>
        <li class="active">Contact us</li>
      </ol>
    </div>
  </div>
</div>
<div class="map" id="map">
    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15302.449663448633!2d80.6620975!3d16.4951518!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a35fac395c10f05%3A0xdf77721717f3d9b8!2sSampreeth%20dental%20clinic!5e0!3m2!1sen!2sin!4v1682604269299!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> 
</div>
<div class="map-info-container">
  <div class="map-info" id="map-info">
    <div class="map-info-contacts">      
      <div class="map-info-phone"> <i class="fa fa-phone"></i>
        <span>
          <a href="tel:+919440184073">+91 9440 184 073</a>		  
        </span>
      </div>
      <div class="map-info-phone"> <i class="fa fa-phone"></i>
        <span>
          <a href="tel:+919866516662">+91 9866 516 662</a>
        </span>
      </div>
      <div class="map-info-mail"> <i class="fa fa-envelope"></i>
        <span>
          <a href="mailto:drnadellaneelima@gmail.com">drnadellaneelima@gmail.com</a>
        </span>
      </div>	
	  <div class="map-info-mail"> <i class="fa fa-envelope"></i>
        <span>
          <a href="mailto:koteswararaonadella2010@gmail.com">koteswararaonadella2010@gmail.com</a>
        </span>
      </div>
    </div>
       <div class="map-info-socials"> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-google-plus"></i></a> <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-skype"></i></a> </div>
  </div>
</div>
<div class="get">
  <div class="container">
    <div class="row">
      <h2 class="section-title">how to get Us</h2>
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 get-item">
        <div class="get-item-icon"> <i class="flaticon-navigation-arrow"></i> </div>
        <h4 class="get-item-title">Reach Us</h4>
        <p class="get-item-text">#57-6-2, Venkata Sai Enclave, Old Post Office Road, Opp:Sri Chaitanya English Medium High School, Patamata, Vijayawada - 10.</p>
      </div>
      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 get-item">
        <div class="get-item-icon"> <i class="fa fa-phone"></i> </div>
        <h4 class="get-item-title">Phone</h4>
        <p class="get-item-text"><a href="tel:+917995605888">+91 79956 05888</a> </p>
      </div>
    </div>
  </div>
</div>

<div class="feedback">
  <div class="container">
    <div class="row">
      <h2 class="section-title">
        <span class="bold700">
          CONTACT US
        </span>
      </h2>
      <p class="section-subtitle">Our Clinic has grown to provide a world class facility for the treatment of tooth loss, dental cosmetics and advanced restorative dentistry. </p>
      <form>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item name">
              <input type="text" name="name" id="name" data-validation="required" placeholder="Your name" />
              <div class="help help-sm help-red">!</div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item phone">
              <input type="text" name="phone" id="phone" data-validation="required" placeholder="Phone" />
              <div class="help help-sm help-red">!</div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item email">
              <input type="text" name="email" id="email" placeholder="E-mail" />
            </div>
          </div>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
              <textarea name="message" id="message" data-validation="required" placeholder="Your message.."></textarea>
              <div class="help help-sm help-red">!</div>
            </div>
          </div>
        </div>
        <div class="row" style="display:none;">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item honeypot">
            <label class="fl_label">Honeypot:</label>
            <input type="text" name="last" value="" class="form-control fl_input">
          </div>
        </div>
        <div class="row latest-row">
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
            <button class="btn btn-primary">
              SEND
            </button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- =========================
    FOOTER
============================== -->
<div class="footer">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 footer-matchheight">
        <div class="row"> 
          
          <!-- FOOTER ITEM 1 -->
          <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 footer-item footer-item-1">
            <h3 class="footer-title footer-title-line"> About Us</h3>
            <div class="tweet">
              <div class="tweet-login"> <a href="#" style="font-size:20px;">SAMPREETH DENTAL CLINIC</a> </div>
              <div class="tweet-text"><p style="font-size:15px"> We provide team-based, comprehensive dental care for children and adults, including patients of all ages who are anxious or have an underlying developmental or medical condition that may add complexity to the management of their oral health.</p></div>
              <!-- <div class="tweet-date"> 03.10.2016 </div> -->
            </div>
            <!-- <div class="tweet"> -->
              <!-- <div class="tweet-login"> <a href="#">@DentalClinic</a> </div> -->
              <!-- <div class="tweet-text"> Lorem ipsum dolro lobortis quobortisnissim pulvinar ac Lorem. </div> -->
              <!-- <div class="tweet-date"> 03.10.2016 </div> -->
            <!-- </div> -->
            <!-- <div class="tweet"> -->
              <!-- <div class="tweet-login"> <a href="#">@DentalClinic</a> </div> -->
              <!-- <div class="tweet-text"> Lorem ipsum dolro lobortis quobortisnissim pulvinar ac Lorem. </div> -->
              <!-- <div class="tweet-date"> 03.10.2016 </div> -->
            <!-- </div> -->
          </div>
          
          <!-- FOOTER ITEM 2 -->
          <div class="col-lg-8 col-md-6 col-sm-6 col-xs-12 footer-item footer-item-2">
            <h3 class="footer-title footer-title-line"><i class="fa fa-clock-o"></i> OPENING HOURS</h3>
            <div class="opening-left"> Monday<br>
              Tuesday<br>
              Wednesday<br>
              Thursday<br>
              Friday<br>
              Saturday<br>
              Sunday </div>
            <div class="opening-right"> 
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM
            </div>
          </div>
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 footer-copyright">
            <div> Copyright &copy; 2026 SAMPREETH DENTAL CLINIC | Powerb by <a href="https://sab-it.co" target="_blank">SAB IT SERVICES</a> </div>
          </div>
        </div>
      </div>
      
      <!-- FOOTER ITEM 3 -->
	   <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 footer-item  footer-matchheight" id="footer-item-3">
      <!-- <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 footer-item footer-item-3 footer-matchheight" id="footer-item-3"> -->
        <h3 class="footer-title"><i class="fa fa-map-marker"></i> CONTACTS</h3>
        <div class="footer-item-3-phone"> <i class="fa fa-phone"></i> <a href="tel:+917995605888">+91 79956 05888</a> </div>
        <div class="footer-item-3-location"> <i class="flaticon-navigation-arrow"></i> #57-6-2, Venkata Sai Enclave, Old Post Office Road, Opp:Sri Chaitanya English Medium High School, Patamata, Vijayawada - 10.</div>
        <div class="footer-item-3-mail"> 
			<i class="fa fa-envelope"></i> <a href="#">drnadellaneelima@gmail.com</a> 
		</div>
        <div class="footer-item-3-socials"> 
			<a href="#"><i class="fa fa-facebook"></i></a> 
			<a href="#"><i class="fa fa-google-plus"></i></a> 
			<a href="#"><i class="fa fa-twitter"></i></a> 
			<a href="#"><i class="fa fa-skype"></i></a> </div>
      </div>
      
      <!-- FOOTER ITEM 4 -->
      <!-- <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 footer-item footer-item-4 footer-matchheight" id="footer-item-4"> </div> -->
    </div>
  </div>
</div>
<!-- =========================
    END FOOTER
============================== --> 

<!-- =========================
    POPUP FORMS
============================== -->
<div class="bookform bookform-1" id="bookform1">
	<div class="bookform-left">
		<h2 class="section-title"><span class="bold700">BOOK APPOINTMENT</span></h2>
		<form>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item f-doctor">
					<select id="form-doctor" class="form-doctor" name="form-doctor">
						<option value="1" selected="selected">Select doctor</option>
						<option value="2">Dr Nadella Koteswara Rao</option>
						<option value="3">Dr Nadella Neelima</option>
						<option value="4">Dr Kiran Kumar Dodda</option>
						<option value="5">Dr Srikanth Koya</option>
						<option value="6">Dr Ravi Kiran V</option>
						<option value="7">Dr Satya Karthik M</option>
						<option value="8">Dr Prasanna</option>
					</select>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item name">
					<input type="text" name="name1" id="name1" data-validation="required" placeholder="Your name" />
					<div class="help help-sm help-red">!</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item phone">
					<input type="text" name="phone1" id="phone1" data-validation="required" placeholder="Phone" />
					<div class="help help-sm help-red">!</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item email">
					<input type="text" name="email1" id="email1" placeholder="E-mail" />
				</div>
			</div>
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item date">
					<input type="text" class="datepicker-f" id="datepicker1" name="date1" data-validation="required" placeholder="Date" />
					<div class="help help-sm help-red">!</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item time-f">
					<input type="text" class="timepicker-f" id="timepicker1" name="time1" data-validation="required" placeholder="Time" />
					<div class="help help-sm help-red">!</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
					<textarea name="message1" id="message1" placeholder="Your message.."></textarea>
				</div>
			</div>
			<div class="row" style="display:none;">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item honeypot">
					<label class="fl_label">Honeypot:</label>
					<input type="text" name="last" value="" class="form-control fl_input">
				</div>
			</div>
			<div class="row latest-row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
					<button class="btn btn-primary">SUBMIT</button>
					<a class="fb-close" id="fb-close1" href="javascript:jQuery.fancybox.close();">Cancel</a>
				</div>
			</div>
		</form>
	</div>
	<div class="bookform-right">
		<div class="bookform-right-info-1">
			<h5>Please select a doctor</h5>
			Some Content Goes Here 
		</div>
		<div class="bookform-right-info-2"> Some Content Goes Here </div>
	</div>
	<div class="bookform-right">
		<div class="doctor-info">
			<div class="doctor-info-image"> <img src="images/doctor01.jpg" alt="" /> </div>
			<div class="doctor-info-name"> Dr Nadella Koteswara Rao </div>
			<div class="doctor-info-position"> Oral& Maxillofacial Surgeon </div>
			<div class="doctor-info-hours-title"> OPENING HOURS </div>
			<div class="doctor-info-hours">
				<div class="doctor-info-hours-clock"> <img src="images/clock.png" alt="" /> </div>
				<div class="doctor-info-hours-left"> 
					Monday<br>
					Tuesday<br>
					Wednesday<br>
					Thursday<br>
					Friday<br>
					Saturday<br>
					Sunday 
				</div>
				<div class="doctor-info-hours-right"> Closed<br>
					10:00 am - 9:00 pm<br>
					10:00 am - 9:00 pm<br>
					10:00 am - 9:00 pm<br>
					10:00 am - 9:00 pm<br>
					10:00 am - 9:00 pm<br>
					10:00 am - 1:00 pm
				</div>
			</div>
			<div class="doctor-info-desc"> 
				
			</div>
		</div>
	</div>
</div>
	
<div class="bookform" id="bookform2">
  <div class="bookform-left">
	<h2 class="section-title">
	  <span class="bold700">
		BOOK APPOINTMENT
	  </span>
	</h2>
	<form>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item name">
		  <input type="text" name="name6" id="name6" data-validation="required" placeholder="Your name" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item phone">
		  <input type="text" name="phone6" id="phone6" data-validation="required" placeholder="Phone" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item email">
		  <input type="text" name="email6" id="email6" placeholder="E-mail" />
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item date">
		  <input type="text" class="datepicker-f" id="datepicker6" name="date6" data-validation="required" placeholder="Date" />
		  <div class="help help-sm help-red">!</div>
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item time-f">
		  <input type="text" class="timepicker-f" id="timepicker6" name="time6" data-validation="required" placeholder="Time" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
		  <textarea name="message6" id="message6" placeholder="Your message.."></textarea>
		</div>
	  </div>
	  <div class="row" style="display:none;">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item honeypot">
		  <label class="fl_label" >Honeypot:</label>
		  <input type="text" name="last" value="" class="form-control fl_input">
		</div>
	  </div>
	  <div class="row latest-row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
		  <button class="btn btn-primary">
			SUBMIT
		  </button>
		  <a class="fb-close" id="fb-close6" href="javascript:jQuery.fancybox.close();">Cancel</a> </div>
	  </div>
	</form>
  </div>
  <div class="bookform-right">
	<div class="doctor-info">
	  <div class="doctor-info-image"> <img src="images/doctor01.jpg" alt="" /> </div>
	  <div class="doctor-info-name"> Dr Nadella Koteswara Rao </div>
	  <div class="doctor-info-position"> Oral& Maxillofacial Surgeon </div>
	  <div class="doctor-info-hours-title"> OPENING HOURS </div>
	  <div class="doctor-info-hours">
		<div class="doctor-info-hours-clock"> <img src="images/clock.png" alt="" /> </div>
		<div class="doctor-info-hours-left"> Monday<br>
		  Tuesday<br>
		  Wednesday<br>
		  Thursday<br>
		  Friday<br>
		  Saturday<br>
		  Sunday </div>
		<div class="doctor-info-hours-right"> Closed<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 1:00 pm </div>
	  </div>
	  <div class="doctor-info-desc"> </div>
	</div>
  </div>
</div>

<div class="bookform" id="bookform3">
  <div class="bookform-left">
	<h2 class="section-title">
	  <span class="bold700">
		BOOK APPOINTMENT
	  </span>
	</h2>
	<form>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item name">
		  <input type="text" name="name6" id="name6" data-validation="required" placeholder="Your name" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item phone">
		  <input type="text" name="phone6" id="phone6" data-validation="required" placeholder="Phone" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item email">
		  <input type="text" name="email6" id="email6" placeholder="E-mail" />
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item date">
		  <input type="text" class="datepicker-f" id="datepicker6" name="date6" data-validation="required" placeholder="Date" />
		  <div class="help help-sm help-red">!</div>
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item time-f">
		  <input type="text" class="timepicker-f" id="timepicker6" name="time6" data-validation="required" placeholder="Time" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
		  <textarea name="message6" id="message6" placeholder="Your message.."></textarea>
		</div>
	  </div>
	  <div class="row" style="display:none;">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item honeypot">
		  <label class="fl_label" >Honeypot:</label>
		  <input type="text" name="last" value="" class="form-control fl_input">
		</div>
	  </div>
	  <div class="row latest-row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
		  <button class="btn btn-primary">
			SUBMIT
		  </button>
		  <a class="fb-close" id="fb-close6" href="javascript:jQuery.fancybox.close();">Cancel</a> </div>
	  </div>
	</form>
  </div>
  <div class="bookform-right">
	<div class="doctor-info">
	  <div class="doctor-info-image"> <img src="images/doctor02.jpg" alt="" /> </div>
	  <div class="doctor-info-name"> Dr Nadella Neelima </div>
	  <div class="doctor-info-position"> Dental Surgeon </div>
	  <div class="doctor-info-hours-title"> OPENING HOURS </div>
	  <div class="doctor-info-hours">
		<div class="doctor-info-hours-clock"> <img src="images/clock.png" alt="" /> </div>
		<div class="doctor-info-hours-left"> Monday<br>
		  Tuesday<br>
		  Wednesday<br>
		  Thursday<br>
		  Friday<br>
		  Saturday<br>
		  Sunday </div>
		<div class="doctor-info-hours-right"> Closed<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 1:00 pm </div>
	  </div>
	  <div class="doctor-info-desc"> </div>
	</div>
  </div>
</div>
<!-- =========================
    END POPUP FORMS
============================== -->

<div class="totop" id="totop"> <i class="fa fa-angle-up"></i> </div>

<!-- =========================
    COLOR SWITHER
============================== -->
<!-- <div class="color-sw-open" id="color-sw-open"> <i class="fa fa-gear"></i> </div> -->
<!-- <div class="color-sw" id="color-sw"> -->
  <!-- <div class="color-sw-header"> Style switcher -->
    <!-- <span class="color-sw-close" id="color-sw-close"> -->
      <!-- <i class="fa fa-close"></i> -->
    <!-- </span> -->
  <!-- </div> -->
  <!-- <div class="color-sw-body"> -->
    <!-- <p>Choose color style</p> -->
    <!-- <div class="color-sw-item active" id="blue"> -->
      <!-- <div></div> -->
    <!-- </div> -->
    <!-- <div class="color-sw-item" id="violet"> -->
      <!-- <div></div> -->
    <!-- </div> -->
    <!-- <div class="color-sw-item" id="red"> -->
      <!-- <div></div> -->
    <!-- </div> -->
    <!-- <div class="color-sw-item" id="green"> -->
      <!-- <div></div> -->
    <!-- </div> -->
  <!-- </div> -->
<!-- </div> -->
<!-- =========================
    END COLOR SWITHER
============================== -->

<link rel="stylesheet" type="text/css" href="css/responsive.css" />

<!-- =========================
     SCRIPTS   
============================== --> 
<!-- JQUERY --> 
<script src="js/jquery-2.2.0.min.js"></script> 

<!-- BOOTSTRAP --> 
<script src="js/bootstrap.min.js"></script> 

<!-- SLIDER PRO --> 
<script src="js/jquery.sliderPro.min.js"></script> 

<!-- LIGHTBOX --> 
<script src="js/jquery.fancybox.pack.js"></script> 

<!-- CAROUSEL --> 
<script src="js/owl.carousel.js"></script> 

<!-- STAR RATING --> 
<script src="js/jquery.barrating.min.js"></script> 

<!-- ISOTOPE FILTER --> 
<script src="js/isotope.pkgd.min.js"></script> 

<!-- SCROLLSPY --> 
<script src="js/scrollspy.js"></script> 

<!-- DATEPICKER --> 
<script src="js/moment.js"></script> 
<script src="js/bootstrap-datetimepicker.min.js"></script> 

<!-- FORM VALIDATOR --> 
<script src="js/jquery.form-validator.js"></script> 

<!-- SELECT STYLING --> 
<script src="js/jquery.selectBox.js"></script> 

<!-- MATCHHEIGHT --> 
<script src="js/jquery.matchHeight.js"></script> 

<!-- JQUERY FORM --> 
<script src="js/jquery.form.html"></script> 

<!-- IMAGES LOADED --> 
<script src="js/imagesloaded.pkgd.min.js"></script> 

<!-- CUSTOM SCRIPT --> 
<script src="js/theme.js"></script> 

<!-- GOOGLE MAPS --> 
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCIt0-3xYygh5jhA2YCRcEP9YsLO3mw0co&amp;language=en&amp;amp&amp;sensor=true"></script> 
</body>
</html>