<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Specialized dental care to straighten crooked teeth in children and adults. Treat diseases of the gums and the placement of dental implants.">
<meta name="keywords" content="Sampreeth Dental Clinic, Vijayawada Dental Clinic, Top 10 Dental Doctors in Vijayawada, Most Rated Dental Doctor in vijayawada">
<meta name="author" content="Sampreeth Dental Clinc">

<!-- SITE TITLE -->
<title>Sampreeth Dental Clinc | Vijayawada, Andhra Pradesh</title>

<!-- =========================
      FAV AND TOUCH ICONS  
============================== -->
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="apple-touch-icon" href="images/apple-touch-icon.html">
<link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.html">
<link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.html">

<!-- =========================
     STYLESHEETS   
============================== -->

<link rel="stylesheet" type="text/css" href="css/master.css" />
</head>

<body data-spy="scroll" data-target=".navbar">
	<div class="preloader" id="preloader"> 
		<img src="images/preloader.gif" alt="" /> 
	</div>

<!-- =========================
     TOP BAR
============================== -->
<div class="top-bar" id="top-bar">
  <div class="container">
    <div class="row"> 
      
      <!-- TOP BAR LEFT -->
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-8">
        <div class="top-bar-adress"> <i class="flaticon-navigation-arrow"></i> #57-6-2, Venkata Sai Enclave, Opp:Sri Chaitanya English Medium High School, Patamata, Vijayawada. </div>
      </div>
      
      <!-- TOP BAR RIGHT -->
      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
        <div class="top-bar-social"> 
            <a href="#"><i class="fa fa-facebook"></i></a> 
            <a href="#"><i class="fa fa-google-plus"></i></a> 
            <a href="#"><i class="fa fa-twitter"></i></a> 
            <a href="#"><i class="fa fa-skype"></i></a> </div>
        <div class="top-bar-mail"> <i class="fa fa-envelope"></i> <a href="mailto:drnadellaneelima@gmail.com">drnadellaneelima@gmail.com</a> </div>
      </div>
    </div>
  </div>
</div>
<!-- =========================
     END TOP BAR   
============================== --> 

<!-- =========================
     HEADER
============================== -->
<div class="header" id="header">
  <div class="container">
    <div class="row"> 
      
      <!-- HEADER LOGO -->
      <div class="col-lg-6 col-md-6 col-sm-5 col-xs-12">
        <div class="header-logo"> 
            <a href="index.php">
                <img src="img/lg.jpg" alt=""/>
                <span class="bold600 color-child-6">SAMPREETH</span>
                <span class="color-child-5">DENTAL CLINIC</span>
            </a> 
        </div>
      </div>
      
      <!-- HEADER BUTTONS -->
      <div class="col-lg-6 col-md-6 col-sm-7 col-xs-12">
        <div class="header-button"> <a href="#bookform1" class="fancybox-2 btn btn-default">
            <span class="plus">+</span>MAKE AN APPOINTMENT</a> 
		</div>
        <div class="header-phone"> 
			<i class="fa fa-phone"></i> <a href="tel:+917995605888">+91 79956 05888</a>
		</div>
      </div>
    </div>
  </div>
</div>
<!-- =========================
     END HEADER
============================== --> 

<!-- =========================
     MAIN MENU
============================== -->
<div class="top-menu" id="top-menu">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="mobile-bar-cont">
          <div class="top-menu-logo"> <a href="index.php"><img src="img/lg.jpg" alt="" />
              <span class="bold600 color-child-6">
                SAMPREETH
              </span>
              <span class="color-child-5">
                DENTAL CLINIC
              </span>
            </a> </div>
          <div class="mobile-bar">
            <div class="show-menu" id="show-menu"> <i class="fa fa-bars"></i> </div>
            <div class="color-sw-open-1" id="color-sw-open-1"> <i class="fa fa-gear"></i> </div>
          </div>
        </div>
        <ul class="nav navbar-nav">
          <li class="active"><a href="index.php">HOME</a></li>
          <li><a href="about.php">ABOUT US</a></li>
          <li class="dropdown"> <a data-toggle="dropdown" href="">TREATMENTS</a>
            <ul class="dropdown-menu " role="menu">              
				<li><a href="services.php">Teeth whitening</a></li> 
				<li><a href="services.php">Simple Extraction of teeth</a></li> 
				<li><a href="services.php">Surgical removal of Impacted teeth</a></li> 
				<li><a href="services.php">Removal of Cysts& Tumours</a></li> 
				<li><a href="services.php">Fracture Jaw bones</a></li> 
				<li><a href="services.php">Cosmetic Procedures</a></li> 
				<li><a href="services.php">Implants</a></li> 
				<li><a href="services.php">Removable Dentures& Fixed teeth</a></li> 
				<li><a href="services.php">Root canal Treatments</a></li> 
				<li><a href="services.php">Cleaning & Flap Surgeries</a></li> 
				<li><a href="services.php">Correction of Irregular placed Teeth using Braces</a></li> 
				<li><a href="services.php">Treatment for Child Teeth</a></li> 
            </ul>
          </li>
          <!-- <li class="dropdown"> <a data-toggle="dropdown" href="#">OUR DOCTORS</a> -->
            <!-- <ul class="dropdown-menu" role="menu"> -->
              <!-- <li><a href="doctors.html">Our doctors</a></li> -->
              
            <!-- </ul> -->
          <!-- </li> -->
         
		  <li><a href="gallery.php">GALLERY</a></li>
          <!-- <li class="dropdown"> <a data-toggle="dropdown" href="#">PAGES</a> -->
            <!-- <ul class="dropdown-menu" role="menu"> -->
              <!-- <li><a href="gallery1.html">Gallery 1</a></li> -->
              <!-- <li><a href="gallery2.html">Gallery 2</a></li> -->
              <!-- <li><a href="prices.html">Prices</a></li> -->
              <!-- <li><a href="timetable.html">Timetable</a></li> -->
              <!-- <li><a href="payment.html">Payments</a></li> -->
              <!-- <li><a href="404.html">404 Page</a></li> -->
            <!-- </ul> -->
          <!-- </li> -->
          <li><a href="contact.php">CONTACT US</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>
<!-- =========================
     END MAIN MENU
============================== --> 

<!-- =========================
     HEADER SLIDER
============================== -->
<div id="slider" class="slider">
	<div class="sp-slides"> 
    
		<!-- HEADER SLIDER ITEM -->
		<div class="sp-slide"> 
			<img class="sp-image" src="css/images/blank.gif" alt="" data-src="images/slide_01.jpg" />
			<div class="container">
				<h3 class="sp-layer slider-welcome" data-position="leftCenter" data-horizontal="15" data-vertical="-370" data-show-transition="left" data-hide-transition="left" data-show-delay="0" data-hide-delay="0"> Welcome Dental Clinic </h3>
				<h1 class="sp-layer slider-title" data-position="leftCenter" data-horizontal="15" data-vertical="-230"  data-show-transition="left" data-hide-transition="left" data-show-delay="200" data-hide-delay="200"> It is quite simple! </h1>
				<h2 class="sp-layer slider-subtitle" data-position="leftCenter" data-horizontal="15" data-vertical="-120" data-show-transition="left" data-hide-transition="left" data-show-delay="400" data-hide-delay="400"> You choose convenient time! </h2>
				<p class="sp-layer slider-text"  data-position="leftCenter" data-horizontal="15" data-vertical="80"  data-show-transition="left" data-hide-transition="left" data-show-delay="600" data-hide-delay="600">  We provide team-based, comprehensive dental care for children and adults, <br>including patients of all ages who are anxious  </p>
				<p class="sp-layer slider-button"  data-position="leftCenter" data-horizontal="15" data-vertical="300"  data-show-transition="left" data-hide-transition="left" data-show-delay="800" data-hide-delay="800"> <a href="#" class="btn btn-primary">READ MORE</a> </p>
			</div>
		</div>
    
		<!-- HEADER SLIDER ITEM -->
		<div class="sp-slide"> 
			<img class="sp-image" src="css/images/blank.gif" alt="" data-src="images/slide_02.jpg" />
			<div class="container">
				<h3 class="sp-layer slider-welcome" data-position="leftCenter" data-horizontal="15" data-vertical="-370" data-show-transition="left" data-hide-transition="left" data-show-delay="0" data-hide-delay="0"> Healthy kids </h3>
				<h1 class="sp-layer slider-title" data-position="leftCenter" data-horizontal="15" data-vertical="-230" data-show-transition="left" data-hide-transition="left" data-show-delay="200" data-hide-delay="200"> Our concern </h1>
				<h2 class="sp-layer slider-subtitle" data-position="leftCenter" data-horizontal="15" data-vertical="-120" data-show-transition="left" data-hide-transition="left" data-show-delay="400" data-hide-delay="400"> Discount for children Rs. 99 /- </h2>
				<p class="sp-layer slider-text" data-position="leftCenter" data-horizontal="15" data-vertical="80" data-show-transition="left" data-hide-transition="left" data-show-delay="600" data-hide-delay="600">  We provide team-based, comprehensive dental care for children and adults, <br>including patients of all ages who are anxious  </p>
				<p class="sp-layer slider-button" data-position="leftCenter" data-horizontal="15" data-vertical="300" data-show-transition="left" data-hide-transition="left" data-show-delay="800" data-hide-delay="800"> <a href="#" class="btn btn-primary">READ MORE</a> </p>
			</div>
		</div>
    
		<!-- HEADER SLIDER ITEM -->
		<div class="sp-slide"> 
			<img class="sp-image" src="css/images/blank.gif" alt="" data-src="images/slide_03.jpg" />
			<div class="container">
				<h3 class="sp-layer slider-welcome" data-position="leftCenter" data-horizontal="15" data-vertical="-370" data-show-transition="left" data-hide-transition="left" data-show-delay="0" data-hide-delay="0"> A beautiful smile is our task! </h3>
				<h1 class="sp-layer slider-title" data-position="leftCenter" data-horizontal="15" data-vertical="-230" data-show-transition="left" data-hide-transition="left" data-show-delay="200" data-hide-delay="200"> Dental services </h1>
				<h2 class="sp-layer slider-subtitle" data-position="leftCenter" data-horizontal="15" data-vertical="-120" data-show-transition="left" data-hide-transition="left" data-show-delay="400" data-hide-delay="400"> Healthy teeth - healthy body </h2>
				<p class="sp-layer slider-text" data-position="leftCenter" data-horizontal="15" data-vertical="80" data-show-transition="left" data-hide-transition="left" data-show-delay="600" data-hide-delay="600"> We provide team-based, comprehensive dental care for children and adults, <br>including patients of all ages who are anxious  </p>
				<p class="sp-layer slider-button" data-position="leftCenter" data-horizontal="15" data-vertical="300" data-show-transition="left" data-hide-transition="left" data-show-delay="800" data-hide-delay="800"> <a href="#" class="btn btn-primary">READ MORE</a> </p>
			</div>
		</div>
		
	</div>
</div>
<!-- =========================
     END HEADER SLIDER
============================== --> 
<!-- =========================
     SERVICES
============================== -->
<div class="services" id="services"> 
  
  <!-- SERVICES ITEM -->
  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 service bg-primary-2">
    <div class="service-icon"> <i class="flaticon-medical-1"></i> </div>
    <div class="service-title">
      <h3>teeth whitening</h3>
    </div>
    <div class="service-text"> Tooth whitening can be a very effective way of lightening the natural colour of your teeth without removing any of the tooth surface. </div>
  </div>
  
  <!-- SERVICES ITEM -->
  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 service bg-child-2">
    <div class="service-icon"> <i class="flaticon-medical-2"></i> </div>
    <div class="service-title">
      <h3>implants</h3>
    </div>
    <div class="service-text"> Dental implants may be an option for people who have lost a tooth or teeth due to periodontal disease, an injury, or some other reason. </div>
  </div>
  
  <!-- SERVICES ITEM -->
  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 service bg-child-3">
    <div class="service-icon"> <i class="flaticon-tool"></i> </div>
    <div class="service-title">
      <h3>extractions</h3>
    </div>
    <div class="service-text"> In orthodontics if the teeth are crowded, sound teeth may be extracted to create space so the rest of the teeth can be straightened. </div>
  </div>
  
  <!-- SERVICES ITEM -->
  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 service bg-child-4">
    <div class="service-icon"> <i class="flaticon-medical"></i> </div>
    <div class="service-title">
      <h3>gum disease</h3>
    </div>
    <div class="service-text"> Plaque is the primary cause of gum disease. However, other factors can contribute to periodontal disease. </div>
  </div>
</div>
<!-- =========================
     END SERVICES
============================== --> 

<!-- =========================
     ABOUT
============================== -->
<div class="about">
  <div class="container">
    <div class="row"> 
      
      <!-- ABOUT TEXT -->
      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 about-text">
        <h2 class="section-title">
          <span class="bold700">
            ABOUT
          </span>
          OUR CLINIC</h2>
        <p>We provide team-based, comprehensive dental care for children and adults, including patients of all ages who are anxious or have an underlying developmental or medical condition that may add complexity to the management of their oral health.</p>
        <ul class="text-list">
          <li>General Dentistry - preventative and restorative dental care.</li>
          <li>Specialized dental care to straighten crooked teeth in children and adults. </li>
          <li>Treat diseases of the gums and the placement of dental implants.</li>
        </ul>
        <p>We are committed to helping you maintain your oral health as an integral part of your overall health and wellness. <a href="#">Read more &gt;</a></p>
      </div>
      
      <!-- ABOUT BACKGROUND -->
      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 about-bg"> </div>
    </div>
  </div>
</div>
<!-- =========================
     END ABOUT
============================== --> 

<div class="doctors">
	<a href="/dentalimplants.html"></a>
	<div class="container">
		<a href="/dentalimplants.html"></a>
		<div class="row">
			<span class="section-title">MEET <span class="bold700">OUR DOCTORS</span></span>
			<p class="section-subtitle">
				All staff members of Dental Clinic are licensed professionals. Our staff consists of licensed general dentists, hygienists, dental assis-<br> tants, an endodontist, a periodontist, and an oral surgeon.
			</p>
			<div class="doctors-container">
				
				<div class="owl-doctors owl-carousel owl-theme" id="owl-doctors" style="opacity: 1; display: block;">

					<!--- DOCTORS ITEM --->
					<div class="doctors-item">
						<div class="doctors-item-container">
							<div class="doctors-item-image"> 
								<img src="images/doctor01.jpg" alt="" /> 
							</div>
							<div class="doctors-item-name">Dr Nadella Koteswara Rao</div>
							<div class="doctors-item-position">Oral& Maxillofacial Surgeon</div>
						</div>
						<div class="doctors-item-social"> 
							<a href="#"><i class="fa fa-facebook"></i></a> 
							<a href="#"><i class="fa fa-twitter"></i></a> 
							<a href="#"><i class="fa fa-skype"></i></a> 
						</div>
						<div class="doctors-item-button"> 
							<a href="#bookform2" class="fancybox-1 btn btn-default">
								<span class="plus">+</span>BOOK APPOINTMENT
							</a> 
						</div>
					</div>

					<!--- DOCTORS ITEM --->
					<div class="doctors-item">
						<div class="doctors-item-container">
							<div class="doctors-item-image"> 
								<img src="images/doctor02.jpg" alt="" /> 
							</div>
							<div class="doctors-item-name">Dr Nadella Neelima</div>
							<div class="doctors-item-position">Dental Surgeon</div>
						</div>
						<div class="doctors-item-social"> 
							<a href="#"><i class="fa fa-facebook"></i></a> 
							<a href="#"><i class="fa fa-twitter"></i></a> 
							<a href="#"><i class="fa fa-skype"></i></a> 
						</div>
						<div class="doctors-item-button"> 
							<a href="#bookform3" class="fancybox-1 btn btn-default">
								<span class="plus">+</span>BOOK APPOINTMENT
							</a> 
						</div>
					</div> 
				</div>
				
				<!--- DOCTORS BUTTONS --->
				<div class="carousel-btn carousel-next" id="next-doctors">
					<i class="fa fa-angle-right"></i>
				</div>
				<div class="carousel-btn carousel-prev" id="prev-doctors">
					<i class="fa fa-angle-left"></i>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- =========================
     CERTIFICATES
============================== -->
<div class="certs">
  <div class="container">
    <div class="row">
      <h3>Certificates of completion</h3>
      <div class="certs-container">
        <div class="owl-certs" id="owl-certs"> 
        <!-- CERTIFICATES ITEM -->
          <div class="certs-item"> 
			<a href="images/Dr_Neelima_0001.jpg" class="fancybox">
				<img src="images/Dr_Neelima_0001.jpg" alt="" style="width:150px;" />
			</a> 
		  </div>
		  <!-- CERTIFICATES ITEM -->
          <div class="certs-item"> 
			<a href="images/Dr_Neelima_0002.jpg" class="fancybox">
				<img src="images/Dr_Neelima_0002.jpg" alt="" style="width:150px;" />
			</a> 
		  </div>
          <!-- CERTIFICATES ITEM -->
          <div class="certs-item"> 
			<a href="images/koteswara_rao_002.jpg" class="fancybox">
				<img src="images/koteswara_rao_002.jpg" alt="" style="width:150px;" />
			</a> 
		  </div>
		  <!-- CERTIFICATES ITEM -->
          <div class="certs-item"> 
			<a href="images/koteswara_rao_003.jpg" class="fancybox">
				<img src="images/koteswara_rao_003.jpg" alt="" style="width:150px;" />
			</a> 
		  </div>
		  <!-- CERTIFICATES ITEM -->
          <div class="certs-item"> 
			<a href="images/Dr_NKR_page-0001.jpg" class="fancybox">
				<img src="images/Dr_NKR_page-0001.jpg" alt="" style="width:150px;" />
			</a> 
		  </div>
		  <!-- CERTIFICATES ITEM -->
          <div class="certs-item"> 
			<a href="images/Dr_NKR_page-0002.jpg" class="fancybox">
				<img src="images/Dr_NKR_page-0002.jpg" alt="" style="width:150px;" />
			</a> 
		  </div>
		  <!-- CERTIFICATES ITEM -->
          <div class="certs-item"> 
			<a href="images/Dr_NKR_page-0003.jpg" class="fancybox">
				<img src="images/Dr_NKR_page-0003.jpg" alt="" style="width:150px;" />
			</a> 
		  </div>
        </div>
        <!-- CERTIFICATES BUTTONS -->
        <div class="carousel-btn carousel-next" id="next-certs"><i class="fa fa-angle-right"></i></div>
        <div class="carousel-btn carousel-prev" id="prev-certs"><i class="fa fa-angle-left"></i></div>
      </div>
    </div>
  </div>
</div>
<!-- =========================
     END CERTIFICATES
============================== --> 

<!-- =========================
     DOCTORS
============================== -->

<!-- =========================
     END NUMBERS
============================== --> 

<!-- =========================
     STORIES
============================== -->
<div class="stories">
  <div class="container">
    <div class="row">
      <h2 class="section-title">
        <span class="bold700">
          SUCCESS
        </span>
        STORIES</h2>
      <p class="section-subtitle">Happy patients stories</p>
      <div class="certs-container">
        <div class="owl-stories" id="owl-stories"> 
          
          <!-- STORIES ITEM -->
          <div class="stories-item">
            <div class="col-lg-4 col-md-5 col-sm-5 col-xs-12">
              <div class="stories-item-name"> Name </div>
              <div class="stories-item-position"> Position </div>
              <div class="stories-item-rating">
                <select id="stories-rating-1" name="stories-rating-1">
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                </select>
              </div>
              <div class="stories-item-text">
                <div class="stories-item-text-quote"><img src="images/quote.png" alt="" /></div>
                My visits to Dental clinic is always more than just a pleasant experience! I had my cleaning done by Arnie Alban and she did an absolutely impeccable job!! She meticulously and patiently removed the most stubborn stains without causing any discomfort! If you are seeking perfection, then I highly recommend Arnie! </div>
              <div class="stories-item-desc"> Tooth whitening can be a very effective way of lightening the natural colour of your teeth without removing any of the tooth surface.
                <ul>
                  <li>Teeth whitening</li>
                  <li>Teeth cleaning</li>
                </ul>
              </div>
            </div>
            <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
              <div class="stories-item-before"> 
				<img src="images/story/stories01.jpg" alt="" />
                <div class="stories-item-before-title"> BEFORE </div>
              </div>
              <div class="stories-item-after"> 
				<img src="images/story/stories1.jpg" style="width:450px;height:230px" alt="" />
                <div class="stories-item-after-title"> AFTER </div>
              </div>
            </div>
          </div>
          
          <!-- STORIES ITEM -->
          <div class="stories-item">
            <div class="col-lg-4 col-md-5 col-sm-5 col-xs-12">
              <div class="stories-item-name"> Name </div>
              <div class="stories-item-position"> Position </div>
              <div class="stories-item-rating">
                <select id="stories-rating-2" name="stories-rating-2">
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                </select>
              </div>
              <div class="stories-item-text">
                <div class="stories-item-text-quote"><img src="images/quote.png" alt="" /></div>
                I just recently had my braces taken off and to my amazement, underneath was the most beautiful smile I ever could have dreamed possible. I just wanted to thank you for giving me so much to smile about! </div>
              <div class="stories-item-desc"> Orthodontics can give you the straight teeth and proper bite that will help you chew better, smile more often, and keep your teeth longer.
                <ul>
                  <li>Orthodontic treatment</li>
                  <li>Bite correction</li>
                </ul>
              </div>
            </div>
            <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
              <div class="stories-item-before"> 
				<img src="images/story/stories02.jpg" alt="" />
                <div class="stories-item-before-title"> BEFORE </div>
              </div>
              <div class="stories-item-after"> 
				<img src="images/story/stories2.jpg" alt="" />
                <div class="stories-item-after-title"> AFTER </div>
              </div>
            </div>
          </div>
		  
		  <!-- STORIES ITEM -->
          <div class="stories-item">
            <div class="col-lg-4 col-md-5 col-sm-5 col-xs-12">
              <div class="stories-item-name"> Name </div>
              <div class="stories-item-position"> Position </div>
              <div class="stories-item-rating">
                <select id="stories-rating-1" name="stories-rating-1">
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                </select>
              </div>
              <div class="stories-item-text">
                <div class="stories-item-text-quote"><img src="images/quote.png" alt="" /></div>
                My visits to Dental clinic is always more than just a pleasant experience! I had my cleaning done by Arnie Alban and she did an absolutely impeccable job!! She meticulously and patiently removed the most stubborn stains without causing any discomfort! If you are seeking perfection, then I highly recommend Arnie! </div>
              <div class="stories-item-desc"> Tooth whitening can be a very effective way of lightening the natural colour of your teeth without removing any of the tooth surface.
                <ul>
                  <li>Teeth whitening</li>
                  <li>Teeth cleaning</li>
                </ul>
              </div>
            </div>
            <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
              <div class="stories-item-before"> 
				<img src="images/story/stories03.jpg" alt="" />
                <div class="stories-item-before-title"> BEFORE </div>
              </div>
              <div class="stories-item-after"> 
				<img src="images/story/stories3.jpg" style="width:450px;height:230px" alt="" />
                <div class="stories-item-after-title"> AFTER </div>
              </div>
            </div>
          </div>
          
          <!-- STORIES ITEM -->
          <div class="stories-item">
            <div class="col-lg-4 col-md-5 col-sm-5 col-xs-12">
              <div class="stories-item-name"> Name </div>
              <div class="stories-item-position"> Position </div>
              <div class="stories-item-rating">
                <select id="stories-rating-2" name="stories-rating-2">
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                </select>
              </div>
              <div class="stories-item-text">
                <div class="stories-item-text-quote"><img src="images/quote.png" alt="" /></div>
                I just recently had my braces taken off and to my amazement, underneath was the most beautiful smile I ever could have dreamed possible. I just wanted to thank you for giving me so much to smile about! </div>
              <div class="stories-item-desc"> Orthodontics can give you the straight teeth and proper bite that will help you chew better, smile more often, and keep your teeth longer.
                <ul>
                  <li>Orthodontic treatment</li>
                  <li>Bite correction</li>
                </ul>
              </div>
            </div>
            <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
              <div class="stories-item-before"> 
				<img src="images/story/stories04.jpg" alt="" />
                <div class="stories-item-before-title"> BEFORE </div>
              </div>
              <div class="stories-item-after"> 
				<img src="images/story/stories4.jpg" alt="" />
                <div class="stories-item-after-title"> AFTER </div>
              </div>
            </div>
          </div>
		  
		  <!-- STORIES ITEM -->
          <div class="stories-item">
            <div class="col-lg-4 col-md-5 col-sm-5 col-xs-12">
              <div class="stories-item-name"> Name </div>
              <div class="stories-item-position"> Position </div>
              <div class="stories-item-rating">
                <select id="stories-rating-1" name="stories-rating-1">
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                </select>
              </div>
              <div class="stories-item-text">
                <div class="stories-item-text-quote"><img src="images/quote.png" alt="" /></div>
                My visits to Dental clinic is always more than just a pleasant experience! I had my cleaning done by Arnie Alban and she did an absolutely impeccable job!! She meticulously and patiently removed the most stubborn stains without causing any discomfort! If you are seeking perfection, then I highly recommend Arnie! </div>
              <div class="stories-item-desc"> Tooth whitening can be a very effective way of lightening the natural colour of your teeth without removing any of the tooth surface.
                <ul>
                  <li>Teeth whitening</li>
                  <li>Teeth cleaning</li>
                </ul>
              </div>
            </div>
            <div class="col-lg-8 col-md-7 col-sm-7 col-xs-12">
              <div class="stories-item-before"> 
				<img src="images/story/stories05.jpg" alt="" />
                <div class="stories-item-before-title"> BEFORE </div>
              </div>
              <div class="stories-item-after"> 
				<img src="images/story/stories5	.jpg" style="width:450px;height:230px" alt="" />
                <div class="stories-item-after-title"> AFTER </div>
              </div>
            </div>
          </div>
		  
		  
        </div>
        <div class="carousel-btn carousel-next" id="next-stories"><i class="fa fa-angle-right"></i></div>
        <div class="carousel-btn carousel-prev" id="prev-stories"><i class="fa fa-angle-left"></i></div>
      </div>
    </div>
  </div>
</div>
<!-- =========================
    END STORIES
============================== --> 

<!-- =========================
    REVIEW
============================== -->
<div class="review">
  <div class="container">
    <div class="row">
      <h2 class="section-title">
        <span class="bold700">
          TESTIMONIALS
        </span>
      </h2>
      <p class="section-subtitle">Many of our patients are our friends now, and they recommend our Dental clinic to their friends and come with their children and<br>
        senior parents to us. We are very proud that you entrust the health of your relatives to us! </p>
      <div class="review-container">
        <div class="owl-review" id="owl-review"> 
          
          <!-- REVIEW ITEM -->
          <div class="review-item">
            <div class="review-item-image"> <img src="img/per.jpg" alt="" style="width:90px;height:90px" /> </div>
            <div class="review-item-text">This was my first dental treatment in many years and Dr. Callahan made me feel relaxed and calm. It was completely painless and issue free. I thoroughly recommend both Dr. Callahan and Dental clinic. Excellent caring staff! </div>
            <div class="review-item-name">Name</div>
            <div class="review-item-position">Comprehensive Cleaning</div>
            <div class="review-item-quote"><img src="images/quote.png" alt="" /></div>
          </div>
          
          <!-- REVIEW ITEM -->
          <div class="review-item">
            <div class="review-item-image"> <img src="img/per.jpg" alt="" style="width:90px;height:90px" /></div>
            <div class="review-item-text">I would like to say a big thank you to all the team at Dental Clinic, from the charming and efficient reception staff to all the dental team. Dr Wyatt's is a truly first class outfit that are the epitome of professionalism. Satisfied with the service. </div>
            <div class="review-item-name">Name</div>
            <div class="review-item-position">General Dentistry</div>
            <div class="review-item-quote"><img src="images/quote.png" alt="" /></div>
          </div>
          
          <!-- REVIEW ITEM -->
          <div class="review-item">
            <div class="review-item-image"> <img src="img/per.jpg" alt="" style="width:90px;height:90px" /></div>
            <div class="review-item-text">I'm new to Dental Clinic and I have got to say that I am rather impressed with their team's professionalism. I booked online through their website, and I immediately got a call from Diana, their receptionist, confirming my appointment. </div>
            <div class="review-item-name">Name</div>
            <div class="review-item-position">Teeth Whitening</div>
            <div class="review-item-quote"><img src="images/quote.png" alt="" /></div>
          </div>
          
          <!-- REVIEW ITEM -->
          <div class="review-item">
            <div class="review-item-image"> <img src="img/per.jpg" alt="" style="width:90px;height:90px" /></div>
            <div class="review-item-text">Hands down the best dental clinic I've been to. You'll pay a little more than other clinics but you'll get it right the first time. From the reception to the coffee and down to the dentists; simply awesome! Great customer service. Very satisfied. </div>
            <div class="review-item-name">Name</div>
            <div class="review-item-position">Crown, Root Canal</div>
            <div class="review-item-quote"><img src="images/quote.png" alt="" /></div>
          </div>
        </div>
        <!-- REVIEW BUTTONS -->
        <div class="carousel-btn carousel-next" id="next-review"><i class="fa fa-angle-right"></i></div>
        <div class="carousel-btn carousel-prev" id="prev-review"><i class="fa fa-angle-left"></i></div>
      </div>
    </div>
  </div>
</div>
<!-- =========================
    END REVIEW
============================== --> 

<!-- =========================
    BLOG
============================== -->

<!-- =========================
    END BLOG
============================== --> 

<!-- =========================
    TIPS AND FAQ
============================== -->
<div class="tipsfaq">
  <div class="container">
    <div class="row"> 
      
      <!-- TIPS -->
      <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12 tips">
        <h2 class="section-title">
          <span class="bold700">
            TOP TIPS
          </span>
          FROM DOCTORS</h2>
        <!-- TIPS NAVS -->
        <div class="tips-tabs">
          <ul class="nav nav-tabs tabs-carousel">
            <li class="active"><a href="#tips1" data-toggle="tab">Teeth whitening</a></li>
            <li><a href="#tips2" data-toggle="tab">Oral exams</a></li>
            <li><a href="#tips3" data-toggle="tab">Fillings and bridges</a></li>
            <li><a href="#tips4" data-toggle="tab">Root canals</a></li>
            <li><a href="#tips5" data-toggle="tab">Oral exams</a></li>
            <li><a href="#tips6" data-toggle="tab">Root canals</a></li>
          </ul>
          <div class="tips-btn tips-next" id="next-tips"><i class="fa fa-angle-right"></i></div>
          <div class="tips-btn tips-prev" id="prev-tips"><i class="fa fa-angle-left"></i></div>
        </div>
        <!-- TIPS ITEMS -->
        <div class="tips-content">
          <div class="tab-content"> 
            
            <!-- TIPS ITEM -->
            <div class="tab-pane fade active in tips-content-item" id="tips1">
              <div class="tips-content-item-text">
                <p>Tooth whitening (termed tooth bleaching when utilizing bleach), is either restoration of natural tooth shade or whitening beyond natural tooth shade, depending on the definition used.</p>
                <p>Restoration of the underlying, natural tooth shade is possible by simply removing surface (extrinsic) stains (e.g. from tea, coffee, red wine and tobacco) and calculus (tartar). This is achieved by having the teeth cleaned by a dental professional (commonly termed "scale and polish".</p>
                <div class="tips-content-item-btn"> <a href="#" class="btn btn-primary-1">READ MORE</a> </div>
              </div>
              <div class="tips-content-item-image"> <img src="img/per.jpg" alt="" style="width:90px;height:90px" />
                <div class="tips-content-item-name"> <a href="#">Dr's Name</a> </div>
                <div class="tips-content-item-position"> Position </div>
              </div>
            </div>
            
            <!-- TIPS ITEM -->
            <div class="tab-pane fade tips-content-item" id="tips2">
              <div class="tips-content-item-text">
                <p>Tooth whitening (termed tooth bleaching when utilizing bleach), is either restoration of natural tooth shade or whitening beyond natural tooth shade, depending on the definition used.</p>
                <p>Restoration of the underlying, natural tooth shade is possible by simply removing surface (extrinsic) stains (e.g. from tea, coffee, red wine and tobacco) and calculus (tartar). This is achieved by having the teeth cleaned by a dental professional (commonly termed "scale and polish".</p>
                <div class="tips-content-item-btn"> <a href="#" class="btn btn-primary-1">READ MORE</a> </div>
              </div>
              <div class="tips-content-item-image"> <img src="img/per.jpg" alt="" style="width:90px;height:90px" />
                <div class="tips-content-item-name"> <a href="#">Dr's Name</a> </div>
                <div class="tips-content-item-position"> Position </div>
              </div>
            </div>
            
            <!-- TIPS ITEM -->
            <div class="tab-pane fade tips-content-item" id="tips3">
              <div class="tips-content-item-text">
                <p>Tooth whitening (termed tooth bleaching when utilizing bleach), is either restoration of natural tooth shade or whitening beyond natural tooth shade, depending on the definition used.</p>
                <p>Restoration of the underlying, natural tooth shade is possible by simply removing surface (extrinsic) stains (e.g. from tea, coffee, red wine and tobacco) and calculus (tartar). This is achieved by having the teeth cleaned by a dental professional (commonly termed "scale and polish".</p>
                <div class="tips-content-item-btn"> <a href="#" class="btn btn-primary-1">READ MORE</a> </div>
              </div>
              <div class="tips-content-item-image"> <img src="img/per.jpg" alt="" style="width:90px;height:90px" />
                <div class="tips-content-item-name"> <a href="#">Dr's Name </a> </div>
                <div class="tips-content-item-position"> Position </div>
              </div>
            </div>
            
            <!-- TIPS ITEM -->
            <div class="tab-pane fade tips-content-item" id="tips4">
              <div class="tips-content-item-text">
                <p>Tooth whitening (termed tooth bleaching when utilizing bleach), is either restoration of natural tooth shade or whitening beyond natural tooth shade, depending on the definition used.</p>
                <p>Restoration of the underlying, natural tooth shade is possible by simply removing surface (extrinsic) stains (e.g. from tea, coffee, red wine and tobacco) and calculus (tartar). This is achieved by having the teeth cleaned by a dental professional (commonly termed "scale and polish".</p>
                <div class="tips-content-item-btn"> <a href="#" class="btn btn-primary-1">READ MORE</a> </div>
              </div>
              <div class="tips-content-item-image"> <img src="img/per.jpg" alt="" style="width:90px;height:90px" />
                <div class="tips-content-item-name"> <a href="#">Dr's Name</a> </div>
                <div class="tips-content-item-position"> Position </div>
              </div>
            </div>
            
           
            <!-- <div class="tab-pane fade tips-content-item" id="tips5"> -->
              <!-- <div class="tips-content-item-text"> -->
                <!-- <p>Tooth whitening (termed tooth bleaching when utilizing bleach), is either restoration of natural tooth shade or whitening beyond natural tooth shade, depending on the definition used.</p> -->
                <!-- <p>Restoration of the underlying, natural tooth shade is possible by simply removing surface (extrinsic) stains (e.g. from tea, coffee, red wine and tobacco) and calculus (tartar). This is achieved by having the teeth cleaned by a dental professional (commonly termed "scale and polish".</p> -->
                <!-- <div class="tips-content-item-btn"> <a href="#" class="btn btn-primary-1">READ MORE</a> </div> -->
              <!-- </div> -->
              <!-- <div class="tips-content-item-image"> <img src="images/blog_author5.jpg" alt="" /> -->
                <!-- <div class="tips-content-item-name"> <a href="#">Leslie Adams</a> </div> -->
                <!-- <div class="tips-content-item-position"> Prosthodontics </div> -->
              <!-- </div> -->
            <!-- </div> -->
            
           
            <!-- <div class="tab-pane fade tips-content-item" id="tips6"> -->
              <!-- <div class="tips-content-item-text"> -->
                <!-- <p>Tooth whitening (termed tooth bleaching when utilizing bleach), is either restoration of natural tooth shade or whitening beyond natural tooth shade, depending on the definition used.</p> -->
                <!-- <p>Restoration of the underlying, natural tooth shade is possible by simply removing surface (extrinsic) stains (e.g. from tea, coffee, red wine and tobacco) and calculus (tartar). This is achieved by having the teeth cleaned by a dental professional (commonly termed "scale and polish".</p> -->
                <!-- <div class="tips-content-item-btn"> <a href="#" class="btn btn-primary-1">READ MORE</a> </div> -->
              <!-- </div> -->
              <!-- <div class="tips-content-item-image"> <img src="images/blog_author6.jpg" alt="" /> -->
                <!-- <div class="tips-content-item-name"> <a href="#">Helen Edwards</a> </div> -->
                <!-- <div class="tips-content-item-position"> Pediatric Dentistry </div> -->
              <!-- </div> -->
            <!-- </div> -->
          </div>
        </div>
      </div>
      
      <!-- FAQ -->
      <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 faq">
        <h2 class="section-title">
          <span class="bold700">
            FAQ
          </span>
        </h2>
        <div class="panel-group" id="accordion"> 
          <!-- FAQ ITEM -->
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne"> <i class="fa fa-heartbeat"></i> Surgical implant placements </a> </h4>
            </div>
            <div id="collapseOne" class="panel-collapse collapse in">
              <div class="panel-body"> Dental implant placement is no longer performed only by oral surgeons and periodontists; general dentists are also increasingly providing difficult surgical implant services. Dental implants may be used to replace single teeth, replace multiple teeth, or provide abutments for complete dentures or partials. This topic focuses on the placement of single-tooth dental implants. </div>
            </div>
          </div>
          
          <!-- FAQ ITEM -->
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" class="collapsed"> <i class="fa fa-medkit"></i> Teeth whitening </a> </h4>
            </div>
            <div id="collapseTwo" class="panel-collapse collapse">
              <div class="panel-body"> Dental implant placement is no longer performed only by oral surgeons and periodontists; general dentists are also increasingly providing difficult surgical implant services. Dental implants may be used to replace single teeth, replace multiple teeth, or provide abutments for complete dentures or partials. This topic focuses on the placement of single-tooth dental implants. </div>
            </div>
          </div>
          
          <!-- FAQ ITEM -->
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree" class="collapsed"> <i class="fa fa-life-bouy"></i> Teeth cleaning </a> </h4>
            </div>
            <div id="collapseThree" class="panel-collapse collapse">
              <div class="panel-body"> Dental implant placement is no longer performed only by oral surgeons and periodontists; general dentists are also increasingly providing difficult surgical implant services. Dental implants may be used to replace single teeth, replace multiple teeth, or provide abutments for complete dentures or partials. This topic focuses on the placement of single-tooth dental implants. </div>
            </div>
          </div>
          
          <!-- FAQ ITEM -->
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapseFour" class="collapsed"> <i class="fa fa-flask"></i> X-rays </a> </h4>
            </div>
            <div id="collapseFour" class="panel-collapse collapse">
              <div class="panel-body"> Dental implant placement is no longer performed only by oral surgeons and periodontists; general dentists are also increasingly providing difficult surgical implant services. Dental implants may be used to replace single teeth, replace multiple teeth, or provide abutments for complete dentures or partials. This topic focuses on the placement of single-tooth dental implants. </div>
            </div>
          </div>
          
          <!-- FAQ ITEM -->
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title"> <a data-toggle="collapse" data-parent="#accordion" href="#collapseFive" class="collapsed"> <i class="fa fa-ambulance"></i> Crowns </a> </h4>
            </div>
            <div id="collapseFive" class="panel-collapse collapse">
              <div class="panel-body"> Dental implant placement is no longer performed only by oral surgeons and periodontists; general dentists are also increasingly providing difficult surgical implant services. Dental implants may be used to replace single teeth, replace multiple teeth, or provide abutments for complete dentures or partials. This topic focuses on the placement of single-tooth dental implants. </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- =========================
    END TIPS AND FAQ
============================== --> 

<!-- =========================
    CLIENTS
============================== -->
<!-- <div class="clients"> -->
  <!-- <div class="container"> -->
    <!-- <div class="row"> -->
      <!-- <p class="section-subtitle">PARTNER COMPANIES</p> -->
      <!-- <div class="clients-container"> -->
        <!-- <div class="owl-clients" id="owl-clients">  -->
          
          
          <!-- <div class="clients-item"> <img src="images/clients1.jpg" alt="" /> </div> -->
          
        
          <!-- <div class="clients-item"> <img src="images/clients2.jpg" alt="" /> </div> -->
          
        
          <!-- <div class="clients-item"> <img src="images/clients3.jpg" alt="" /> </div> -->
      
          <!-- <div class="clients-item"> <img src="images/clients4.jpg" alt="" /> </div> -->
        
          <!-- <div class="clients-item"> <img src="images/clients5.jpg" alt="" /> </div> -->
          
      
          <!-- <div class="clients-item"> <img src="images/clients2.jpg" alt="" /> </div> -->
          
      
          <!-- <div class="clients-item"> <img src="images/clients3.jpg" alt="" /> </div> -->
        <!-- </div> -->
       
        <!-- <div class="carousel-btn carousel-next" id="next-clients"><i class="fa fa-angle-right"></i></div> -->
        <!-- <div class="carousel-btn carousel-prev" id="prev-clients"><i class="fa fa-angle-left"></i></div> -->
      <!-- </div> -->
    <!-- </div> -->
  <!-- </div> -->
<!-- </div> -->
<!-- =========================
    END CLIENTS
============================== --> 

<!-- =========================
    FOOTER
============================== -->
<div class="footer">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 footer-matchheight">
        <div class="row"> 
          
          <!-- FOOTER ITEM 1 -->
          <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 footer-item footer-item-1">
            <h3 class="footer-title footer-title-line"> About Us</h3>
            <div class="tweet">
              <div class="tweet-login"> <a href="#" style="font-size:20px;">SAMPREETH DENTAL CLINIC</a> </div>
              <div class="tweet-text"><p style="font-size:15px"> We provide team-based, comprehensive dental care for children and adults, including patients of all ages who are anxious or have an underlying developmental or medical condition that may add complexity to the management of their oral health.</p></div>
              <!-- <div class="tweet-date"> 03.10.2016 </div> -->
            </div>
            <!-- <div class="tweet"> -->
              <!-- <div class="tweet-login"> <a href="#">@DentalClinic</a> </div> -->
              <!-- <div class="tweet-text"> Lorem ipsum dolro lobortis quobortisnissim pulvinar ac Lorem. </div> -->
              <!-- <div class="tweet-date"> 03.10.2016 </div> -->
            <!-- </div> -->
            <!-- <div class="tweet"> -->
              <!-- <div class="tweet-login"> <a href="#">@DentalClinic</a> </div> -->
              <!-- <div class="tweet-text"> Lorem ipsum dolro lobortis quobortisnissim pulvinar ac Lorem. </div> -->
              <!-- <div class="tweet-date"> 03.10.2016 </div> -->
            <!-- </div> -->
          </div>
          
          <!-- FOOTER ITEM 2 -->
          <div class="col-lg-8 col-md-6 col-sm-6 col-xs-12 footer-item footer-item-2">
            <h3 class="footer-title footer-title-line"><i class="fa fa-clock-o"></i> OPENING HOURS</h3>
            <div class="opening-left"> Monday<br>
              Tuesday<br>
              Wednesday<br>
              Thursday<br>
              Friday<br>
              Saturday<br>
              Sunday </div>
            <div class="opening-right"> 
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM & 4:30 PM - 9:00 PM<br>
                10:00 AM - 1:00 PM
            </div>
          </div>
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 footer-copyright">
            <div> Copyright &copy; 2026 SAMPREETH DENTAL CLINIC | Powerb by <a href="https://sab-it.co" target="_blank">SAB IT SERVICES</a> </div>
          </div>
        </div>
      </div>
      
      <!-- FOOTER ITEM 3 -->
	   <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 footer-item  footer-matchheight" id="footer-item-3">
      <!-- <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 footer-item footer-item-3 footer-matchheight" id="footer-item-3"> -->
        <h3 class="footer-title"><i class="fa fa-map-marker"></i> CONTACTS</h3>
        <div class="footer-item-3-phone"> <i class="fa fa-phone"></i> <a href="tel:+917995605888">+91 79956 05888</a> </div>
        <div class="footer-item-3-location"> <i class="flaticon-navigation-arrow"></i> #57-6-2, Venkata Sai Enclave, Old Post Office Road, Opp:Sri Chaitanya English Medium High School, Patamata, Vijayawada - 10.</div>
        <div class="footer-item-3-mail"> 
			<i class="fa fa-envelope"></i> <a href="#">drnadellaneelima@gmail.com</a> 
		</div>
        <div class="footer-item-3-socials"> 
			<a href="#"><i class="fa fa-facebook"></i></a> 
			<a href="#"><i class="fa fa-google-plus"></i></a> 
			<a href="#"><i class="fa fa-twitter"></i></a> 
			<a href="#"><i class="fa fa-skype"></i></a> </div>
      </div>
      
      <!-- FOOTER ITEM 4 -->
      <!-- <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 footer-item footer-item-4 footer-matchheight" id="footer-item-4"> </div> -->
    </div>
  </div>
</div>
<!-- =========================
    END FOOTER
============================== --> 

<!-- =========================
    POPUP FORMS
============================== -->
<div class="bookform bookform-1" id="bookform1">
	<div class="bookform-left">
		<h2 class="section-title"><span class="bold700">BOOK APPOINTMENT</span></h2>
		<form>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item f-doctor">
					<select id="form-doctor" class="form-doctor" name="form-doctor">
						<option value="1" selected="selected">Select doctor</option>
						<option value="2">Dr Nadella Koteswara Rao</option>
						<option value="3">Dr Nadella Neelima</option>
						<option value="4">Dr Kiran Kumar Dodda</option>
						<option value="5">Dr Srikanth Koya</option>
						<option value="6">Dr Ravi Kiran V</option>
						<option value="7">Dr Satya Karthik M</option>
						<option value="8">Dr Prasanna</option>
					</select>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item name">
					<input type="text" name="name1" id="name1" data-validation="required" placeholder="Your name" />
					<div class="help help-sm help-red">!</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item phone">
					<input type="text" name="phone1" id="phone1" data-validation="required" placeholder="Phone" />
					<div class="help help-sm help-red">!</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item email">
					<input type="text" name="email1" id="email1" placeholder="E-mail" />
				</div>
			</div>
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item date">
					<input type="text" class="datepicker-f" id="datepicker1" name="date1" data-validation="required" placeholder="Date" />
					<div class="help help-sm help-red">!</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item time-f">
					<input type="text" class="timepicker-f" id="timepicker1" name="time1" data-validation="required" placeholder="Time" />
					<div class="help help-sm help-red">!</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
					<textarea name="message1" id="message1" placeholder="Your message.."></textarea>
				</div>
			</div>
			<div class="row" style="display:none;">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item honeypot">
					<label class="fl_label">Honeypot:</label>
					<input type="text" name="last" value="" class="form-control fl_input">
				</div>
			</div>
			<div class="row latest-row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
					<button class="btn btn-primary">SUBMIT</button>
					<a class="fb-close" id="fb-close1" href="javascript:jQuery.fancybox.close();">Cancel</a>
				</div>
			</div>
		</form>
	</div>
	<div class="bookform-right">
		<div class="bookform-right-info-1">
			<h5>Please select a doctor</h5>
			Some Content Goes Here 
		</div>
		<div class="bookform-right-info-2"> Some Content Goes Here </div>
	</div>
	<div class="bookform-right">
		<div class="doctor-info">
			<div class="doctor-info-image"> <img src="images/doctor01.jpg" alt="" /> </div>
			<div class="doctor-info-name"> Dr Nadella Koteswara Rao </div>
			<div class="doctor-info-position"> Oral& Maxillofacial Surgeon </div>
			<div class="doctor-info-hours-title"> OPENING HOURS </div>
			<div class="doctor-info-hours">
				<div class="doctor-info-hours-clock"> <img src="images/clock.png" alt="" /> </div>
				<div class="doctor-info-hours-left"> 
					Monday<br>
					Tuesday<br>
					Wednesday<br>
					Thursday<br>
					Friday<br>
					Saturday<br>
					Sunday 
				</div>
				<div class="doctor-info-hours-right"> Closed<br>
					10:00 am - 9:00 pm<br>
					10:00 am - 9:00 pm<br>
					10:00 am - 9:00 pm<br>
					10:00 am - 9:00 pm<br>
					10:00 am - 9:00 pm<br>
					10:00 am - 1:00 pm
				</div>
			</div>
			<div class="doctor-info-desc"> 
				
			</div>
		</div>
	</div>
</div>
	
<div class="bookform" id="bookform2">
  <div class="bookform-left">
	<h2 class="section-title">
	  <span class="bold700">
		BOOK APPOINTMENT
	  </span>
	</h2>
	<form>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item name">
		  <input type="text" name="name6" id="name6" data-validation="required" placeholder="Your name" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item phone">
		  <input type="text" name="phone6" id="phone6" data-validation="required" placeholder="Phone" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item email">
		  <input type="text" name="email6" id="email6" placeholder="E-mail" />
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item date">
		  <input type="text" class="datepicker-f" id="datepicker6" name="date6" data-validation="required" placeholder="Date" />
		  <div class="help help-sm help-red">!</div>
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item time-f">
		  <input type="text" class="timepicker-f" id="timepicker6" name="time6" data-validation="required" placeholder="Time" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
		  <textarea name="message6" id="message6" placeholder="Your message.."></textarea>
		</div>
	  </div>
	  <div class="row" style="display:none;">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item honeypot">
		  <label class="fl_label" >Honeypot:</label>
		  <input type="text" name="last" value="" class="form-control fl_input">
		</div>
	  </div>
	  <div class="row latest-row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
		  <button class="btn btn-primary">
			SUBMIT
		  </button>
		  <a class="fb-close" id="fb-close6" href="javascript:jQuery.fancybox.close();">Cancel</a> </div>
	  </div>
	</form>
  </div>
  <div class="bookform-right">
	<div class="doctor-info">
	  <div class="doctor-info-image"> <img src="images/doctor01.jpg" alt="" /> </div>
	  <div class="doctor-info-name"> Dr Nadella Koteswara Rao </div>
	  <div class="doctor-info-position"> Oral& Maxillofacial Surgeon </div>
	  <div class="doctor-info-hours-title"> OPENING HOURS </div>
	  <div class="doctor-info-hours">
		<div class="doctor-info-hours-clock"> <img src="images/clock.png" alt="" /> </div>
		<div class="doctor-info-hours-left"> Monday<br>
		  Tuesday<br>
		  Wednesday<br>
		  Thursday<br>
		  Friday<br>
		  Saturday<br>
		  Sunday </div>
		<div class="doctor-info-hours-right"> Closed<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 1:00 pm </div>
	  </div>
	  <div class="doctor-info-desc"> </div>
	</div>
  </div>
</div>

<div class="bookform" id="bookform3">
  <div class="bookform-left">
	<h2 class="section-title">
	  <span class="bold700">
		BOOK APPOINTMENT
	  </span>
	</h2>
	<form>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item name">
		  <input type="text" name="name6" id="name6" data-validation="required" placeholder="Your name" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item phone">
		  <input type="text" name="phone6" id="phone6" data-validation="required" placeholder="Phone" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item email">
		  <input type="text" name="email6" id="email6" placeholder="E-mail" />
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item date">
		  <input type="text" class="datepicker-f" id="datepicker6" name="date6" data-validation="required" placeholder="Date" />
		  <div class="help help-sm help-red">!</div>
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 booking-form-item time-f">
		  <input type="text" class="timepicker-f" id="timepicker6" name="time6" data-validation="required" placeholder="Time" />
		  <div class="help help-sm help-red">!</div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
		  <textarea name="message6" id="message6" placeholder="Your message.."></textarea>
		</div>
	  </div>
	  <div class="row" style="display:none;">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item honeypot">
		  <label class="fl_label" >Honeypot:</label>
		  <input type="text" name="last" value="" class="form-control fl_input">
		</div>
	  </div>
	  <div class="row latest-row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 booking-form-item">
		  <button class="btn btn-primary">
			SUBMIT
		  </button>
		  <a class="fb-close" id="fb-close6" href="javascript:jQuery.fancybox.close();">Cancel</a> </div>
	  </div>
	</form>
  </div>
  <div class="bookform-right">
	<div class="doctor-info">
	  <div class="doctor-info-image"> <img src="images/doctor02.jpg" alt="" /> </div>
	  <div class="doctor-info-name"> Dr Nadella Neelima </div>
	  <div class="doctor-info-position"> Dental Surgeon </div>
	  <div class="doctor-info-hours-title"> OPENING HOURS </div>
	  <div class="doctor-info-hours">
		<div class="doctor-info-hours-clock"> <img src="images/clock.png" alt="" /> </div>
		<div class="doctor-info-hours-left"> Monday<br>
		  Tuesday<br>
		  Wednesday<br>
		  Thursday<br>
		  Friday<br>
		  Saturday<br>
		  Sunday </div>
		<div class="doctor-info-hours-right"> Closed<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 9:00 pm<br>
		  10:00 am - 1:00 pm </div>
	  </div>
	  <div class="doctor-info-desc"> </div>
	</div>
  </div>
</div>
<!-- =========================
    END POPUP FORMS
============================== -->

<div class="totop" id="totop"> <i class="fa fa-angle-up"></i> </div>

<!-- =========================
    COLOR SWITHER
============================== -->
<!-- <div class="color-sw-open" id="color-sw-open"> <i class="fa fa-gear"></i> </div> -->
<!-- <div class="color-sw" id="color-sw"> -->
  <!-- <div class="color-sw-header"> Style switcher -->
    <!-- <span class="color-sw-close" id="color-sw-close"> -->
      <!-- <i class="fa fa-close"></i> -->
    <!-- </span> -->
  <!-- </div> -->
  <!-- <div class="color-sw-body"> -->
    <!-- <p>Choose color style</p> -->
    <!-- <div class="color-sw-item active" id="blue"> -->
      <!-- <div></div> -->
    <!-- </div> -->
    <!-- <div class="color-sw-item" id="violet"> -->
      <!-- <div></div> -->
    <!-- </div> -->
    <!-- <div class="color-sw-item" id="red"> -->
      <!-- <div></div> -->
    <!-- </div> -->
    <!-- <div class="color-sw-item" id="green"> -->
      <!-- <div></div> -->
    <!-- </div> -->
  <!-- </div> -->
<!-- </div> -->
<!-- =========================
    END COLOR SWITHER
============================== -->

<link rel="stylesheet" type="text/css" href="css/responsive.css" />

<!-- =========================
     SCRIPTS   
============================== --> 
<!-- JQUERY --> 
<script src="js/jquery-2.2.0.min.js"></script> 

<!-- BOOTSTRAP --> 
<script src="js/bootstrap.min.js"></script> 

<!-- SLIDER PRO --> 
<script src="js/jquery.sliderPro.min.js"></script> 

<!-- LIGHTBOX --> 
<script src="js/jquery.fancybox.pack.js"></script> 

<!-- CAROUSEL --> 
<script src="js/owl.carousel.js"></script> 

<!-- STAR RATING --> 
<script src="js/jquery.barrating.min.js"></script> 

<!-- ISOTOPE FILTER --> 
<script src="js/isotope.pkgd.min.js"></script> 

<!-- SCROLLSPY --> 
<script src="js/scrollspy.js"></script> 

<!-- DATEPICKER --> 
<script src="js/moment.js"></script> 
<script src="js/bootstrap-datetimepicker.min.js"></script> 

<!-- FORM VALIDATOR --> 
<script src="js/jquery.form-validator.js"></script> 

<!-- SELECT STYLING --> 
<script src="js/jquery.selectBox.js"></script> 

<!-- MATCHHEIGHT --> 
<script src="js/jquery.matchHeight.js"></script> 

<!-- JQUERY FORM --> 
<script src="js/jquery.form.html"></script> 

<!-- IMAGES LOADED --> 
<script src="js/imagesloaded.pkgd.min.js"></script> 

<!-- CUSTOM SCRIPT --> 
<script src="js/theme.js"></script> 

<!-- GOOGLE MAPS --> 
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCIt0-3xYygh5jhA2YCRcEP9YsLO3mw0co&amp;language=en&amp;amp&amp;sensor=true"></script> 
</body>
</html>